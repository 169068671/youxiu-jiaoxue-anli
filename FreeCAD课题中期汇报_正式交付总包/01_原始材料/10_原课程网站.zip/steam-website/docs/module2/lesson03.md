# 📍 第 3 课：控制台的魔法（Python变量的引入）

> **"变量是存储在内存中的数据容器，改变容器里的值，实体的物理尺寸就会随之改变。"**

---

## 📐 物理/数理原理

### 代数中的"未知数"思想

在数学中，我们用 $x$、$y$、$z$ 来表示未知数。在编程中，我们使用**变量**（Variable）来存储和操作数据。

**变量的本质**：
- 变量是内存中的一个"盒子"
- 盒子里可以存放各种数据（数字、文字、列表等）
- 通过变量名来访问和操作这个盒子

**参数化设计的魅力**：
```
传统建模：画一个半径10的圆 → 想改20 → 删除重画
编程建模：radius = 10 → 想改20 → radius = 20 → 自动更新
```

---

## 💻 FreeCAD 脚本

### 基础变量使用

```python
import FreeCAD as App
import Part

doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()

# 定义我们的魔法变量
my_radius = 15      # 圆柱半径
my_height = 30      # 圆柱高度

# 利用变量生成圆柱体
my_cylinder = Part.makeCylinder(my_radius, my_height)

# 显示圆柱体
cyl_obj = doc.addObject("Part::Feature", "MagicCylinder")
cyl_obj.Shape = my_cylinder

doc.recompute()

App.Console.PrintMessage(f"圆柱体生成成功！半径：{my_radius}mm，高度：{my_height}mm\n")
```

### 变量命名规范

```python
# ✅ 好的命名（有意义）
height = 50
radius = 10
wall_thickness = 2

# ❌ 差的命名（无意义）
a = 50
b = 10
c = 2

# ✅ 好的命名（驼峰式或下划线式）
boxHeight = 20      # 驼峰式
box_height = 20     # 下划线式（Python推荐）

# ❌ 错误的命名
2box = 20           # 不能以数字开头
box-height = 20     # 不能包含减号
box height = 20     # 不能包含空格
```

---

## 📋 实验报告

### 观察记录

运行基础变量代码后：
1. ✅ 成功生成了一个圆柱体
2. ✅ 圆柱体的半径为 15mm，高度为 30mm
3. ✅ 控制台输出了详细的尺寸信息

### 变量探究实验

试着修改变量的值，观察效果：

| my_radius | my_height | 效果 |
|:---|:---|:---|
| 5 | 30 | 细长的棍子 |
| 20 | 10 | 扁平的圆盘 |
| 15 | 100 | 高大的柱子 |

### 思考问题

1. 如果 `my_radius = 0` 会发生什么？
2. 如果 `my_height` 是负数会发生什么？

---

## 🔧 制作指南

### 变量的数据类型

Python中常见的数据类型：

```python
# 整数 (int)
length = 100

# 浮点数 (float) - 带小数的数字
pi = 3.14159
radius = 10.5

# 字符串 (str) - 文字
title = "我的第一个3D模型"

# 布尔值 (bool) - 真或假
is_visible = True
has_hole = False

# 查看变量类型
print(type(length))     # <class 'int'>
print(type(pi))         # <class 'float'>
print(type(title))      # <class 'str'>
```

### 变量的运算

```python
import Part

doc = App.ActiveDocument

# 基础尺寸
base_size = 20

# 通过运算得到新的尺寸
box1 = Part.makeBox(base_size, base_size, base_size)
box2 = Part.makeBox(base_size * 2, base_size, base_size)      # 长度翻倍
box3 = Part.makeBox(base_size, base_size / 2, base_size)      # 宽度减半

# 显示所有盒子
for i, box in enumerate([box1, box2, box3], 1):
    obj = doc.addObject("Part::Feature", f"Box{i}")
    obj.Shape = box
    obj.Placement.Base = App.Vector((i-1) * 30, 0, 0)  # 错开位置

doc.recompute()
```

---

## 🎯 课后挑战

### 挑战1：参数化杯子设计

设计一个杯子的基本参数：

```python
import Part

doc = App.ActiveDocument

# 杯子参数
cup_radius = 30         # 杯口半径
cup_height = 80         # 杯高
wall_thickness = 3      # 壁厚
bottom_thickness = 5    # 底厚

# 外圆柱（杯身外部）
outer = Part.makeCylinder(cup_radius, cup_height)

# 内圆柱（挖空部分）
inner_radius = cup_radius - wall_thickness
inner_height = cup_height - bottom_thickness
inner = Part.makeCylinder(inner_radius, inner_height)
inner.translate(App.Vector(0, 0, bottom_thickness))

# 布尔运算：外圆柱减去内圆柱 = 杯身
cup = outer.cut(inner)

cup_obj = doc.addObject("Part::Feature", "MyCup")
cup_obj.Shape = cup

doc.recompute()
```

### 挑战2：变量计算器

创建一个简单的尺寸计算器：

```python
# 输入参数
length = 100
width = 50
height = 30

# 计算
volume = length * width * height          # 体积
surface_area = 2 * (length*width + length*height + width*height)  # 表面积

print(f"长方体尺寸：{length} x {width} x {height} mm")
print(f"体积：{volume} mm³")
print(f"表面积：{surface_area} mm²")
```

---

## 📚 知识小结

### 本课重点

1. ✅ 理解了变量的概念和作用
2. ✅ 掌握了变量的命名规范
3. ✅ 学会了使用变量控制3D模型尺寸

### 关键概念

| 概念 | 说明 |
|:---|:---|
| 变量 | 存储数据的容器 |
| 赋值 | 用 `=` 将值存入变量 |
| 数据类型 | int（整数）、float（浮点数）、str（字符串）、bool（布尔值） |
| 参数化设计 | 通过修改变量值来自动更新模型 |

### 优秀工程师的基本素养

> **变量命名要有意义！** 使用 `height` 而不是随便写个 `a`，这样你的代码才能被他人（以及未来的你自己）理解。

---

> **"变量是代码的灵魂，参数化设计是工程的精髓。"** ✨

---

<p align="center">
  <a href="#/module2/lesson04">下一课：参数化思维（空间位置的向量控制）→</a>
</p>

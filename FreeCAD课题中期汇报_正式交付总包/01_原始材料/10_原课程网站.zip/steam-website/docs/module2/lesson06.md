# 📍 第 6 课：逻辑岔路口（if 条件判断与间隔挖空）

> **"通过判断序号是奇数还是偶数，决定空间的物质是'填充'还是'留空'。"**

---

## 📐 物理/数理原理

### 布尔逻辑与模运算

**布尔逻辑**：只有两种结果——真（True）或假（False）

**模运算（%）**：求余数
- `a % b` 表示a除以b的余数
- 例如：`7 % 3 = 1`，`10 % 2 = 0`

**奇偶判断**：
- 偶数：`i % 2 == 0`（能被2整除，余数为0）
- 奇数：`i % 2 == 1`（不能被2整除，余数为1）

> 💡 **应用场景**：长城城墙顶部的凹凸结构、棋盘格图案、镂空设计等。

---

## 💻 FreeCAD 脚本

### 基础if条件判断

```python
import FreeCAD as App
import Part
from FreeCAD import Vector

doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()

# 创建10个方块，偶数位置显示，奇数位置留空
for i in range(10):
    if i % 2 == 0:  # 如果是偶数
        box = Part.makeBox(5, 5, 5)
        obj = doc.addObject("Part::Feature", f"Block_{i}")
        obj.Shape = box
        obj.Placement.Base = Vector(i*10, 0, 0)
        obj.ViewObject.ShapeColor = (0.2, 0.6, 1.0)
    else:
        # 奇数位置留空，形成虚实结合的城墙效果
        App.Console.PrintMessage(f"位置 {i} 留空\n")

doc.recompute()
```

### if-elif-else结构

```python
import Part
from FreeCAD import Vector

doc = App.ActiveDocument

# 创建彩色条纹
for i in range(12):
    box = Part.makeBox(8, 8, 8)
    obj = doc.addObject("Part::Feature", f"ColorBlock_{i}")
    obj.Shape = box
    obj.Placement.Base = Vector(i*10, 0, 0)
    
    # 根据i的值设置不同颜色
    if i % 3 == 0:
        obj.ViewObject.ShapeColor = (1.0, 0.0, 0.0)  # 红色
    elif i % 3 == 1:
        obj.ViewObject.ShapeColor = (0.0, 1.0, 0.0)  # 绿色
    else:
        obj.ViewObject.ShapeColor = (0.0, 0.0, 1.0)  # 蓝色

doc.recompute()
```

---

## 📋 实验报告

### 观察记录

运行基础条件代码后：
1. ✅ 生成了类似长城城墙顶部的凹凸结构
2. ✅ 偶数位置（0, 2, 4, 6, 8）有方块
3. ✅ 奇数位置（1, 3, 5, 7, 9）留空

### 条件判断追踪

| i值 | i % 2 | 条件 i%2==0 | 结果 |
|:---:|:---:|:---:|:---|
| 0 | 0 | True | 生成方块 |
| 1 | 1 | False | 留空 |
| 2 | 0 | True | 生成方块 |
| 3 | 1 | False | 留空 |
| 4 | 0 | True | 生成方块 |

### 思考问题

1. 如何创建"奇数位置显示，偶数位置留空"？
2. 如何每3个位置留空1个？
3. 如何创建棋盘格图案（二维）？

---

## 🔧 制作指南

### 比较运算符

| 运算符 | 含义 | 示例 | 结果 |
|:---:|:---|:---|:---:|
| `==` | 等于 | `5 == 5` | True |
| `!=` | 不等于 | `5 != 3` | True |
| `<` | 小于 | `3 < 5` | True |
| `>` | 大于 | `5 > 3` | True |
| `<=` | 小于等于 | `5 <= 5` | True |
| `>=` | 大于等于 | `5 >= 3` | True |

> ⚠️ **重要**：`==` 是判断是否相等，`=` 是赋值。在写 if 语句时千万不要搞混！

### 逻辑运算符

```python
# and - 并且（两个条件都满足）
if i > 5 and i < 10:
    print("i在6到9之间")

# or - 或者（至少一个满足）
if i < 3 or i > 7:
    print("i小于3或大于7")

# not - 非（取反）
if not i == 5:
    print("i不等于5")
```

### 嵌套if语句

```python
import Part
from FreeCAD import Vector

doc = App.ActiveDocument

# 创建棋盘格
rows = 5
cols = 5
box_size = 10

for row in range(rows):
    for col in range(cols):
        # 判断是否为黑色格子（棋盘格规律：行号+列号为偶数）
        if (row + col) % 2 == 0:
            box = Part.makeBox(box_size, box_size, 5)
            obj = doc.addObject("Part::Feature", f"Chess_{row}_{col}")
            obj.Shape = box
            obj.Placement.Base = Vector(col*box_size, row*box_size, 0)
            
            # 黑色格子
            obj.ViewObject.ShapeColor = (0.1, 0.1, 0.1)
        else:
            # 白色格子（可以选择生成或不生成）
            box = Part.makeBox(box_size, box_size, 3)
            obj = doc.addObject("Part::Feature", f"Chess_{row}_{col}")
            obj.Shape = box
            obj.Placement.Base = Vector(col*box_size, row*box_size, 0)
            obj.ViewObject.ShapeColor = (0.9, 0.9, 0.9)

doc.recompute()
```

### 综合示例：镂空艺术品

```python
import Part
from FreeCAD import Vector

doc = App.ActiveDocument

# 创建一个带镂空图案的墙面
rows = 8
cols = 8
box_size = 10
hole_size = 6

for row in range(rows):
    for col in range(cols):
        # 镂空条件：行号和列号都是偶数
        if row % 2 == 0 and col % 2 == 0:
            # 实心部分
            box = Part.makeBox(box_size, box_size, 5)
            obj = doc.addObject("Part::Feature", f"Solid_{row}_{col}")
            obj.Shape = box
            obj.Placement.Base = Vector(col*box_size, row*box_size, 0)
            obj.ViewObject.ShapeColor = (0.3, 0.5, 0.8)
        else:
            # 镂空部分（生成较矮的方块）
            box = Part.makeBox(hole_size, hole_size, 2)
            obj = doc.addObject("Part::Feature", f"Hole_{row}_{col}")
            obj.Shape = box
            obj.Placement.Base = Vector(
                col*box_size + (box_size-hole_size)/2,
                row*box_size + (box_size-hole_size)/2,
                0
            )
            obj.ViewObject.ShapeColor = (0.8, 0.8, 0.8)

doc.recompute()
```

---

## 🎯 课后挑战

### 挑战1：创建斐波那契螺旋

```python
import Part
from FreeCAD import Vector

doc = App.ActiveDocument

# 斐波那契数列：1, 1, 2, 3, 5, 8, 13, 21...
fib = [1, 1, 2, 3, 5, 8, 13]

for i, size in enumerate(fib):
    box = Part.makeBox(size, size, 5)
    obj = doc.addObject("Part::Feature", f"Fib_{i}")
    obj.Shape = box
    obj.Placement.Base = Vector(i*25, 0, 0)
    
    # 根据大小设置颜色
    intensity = size / max(fib)
    obj.ViewObject.ShapeColor = (intensity, 0.5, 1-intensity)

doc.recompute()
```

### 挑战2：创建素数筛选图案

```python
import Part
from FreeCAD import Vector

doc = App.ActiveDocument

def is_prime(n):
    """判断是否为素数"""
    if n < 2:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

# 创建1-50的数字阵列
count = 50
box_size = 8
gap = 2

for i in range(1, count + 1):
    if is_prime(i):
        # 素数 - 高亮显示
        box = Part.makeBox(box_size, box_size, 10)
        obj = doc.addObject("Part::Feature", f"Prime_{i}")
        obj.Shape = box
        obj.ViewObject.ShapeColor = (1.0, 0.2, 0.2)  # 红色
    else:
        # 非素数 - 普通高度
        box = Part.makeBox(box_size, box_size, 3)
        obj = doc.addObject("Part::Feature", f"Normal_{i}")
        obj.Shape = box
        obj.ViewObject.ShapeColor = (0.5, 0.5, 0.5)  # 灰色
    
    # 排列成网格（每行10个）
    row = (i - 1) // 10
    col = (i - 1) % 10
    obj.Placement.Base = Vector(col*(box_size+gap), row*(box_size+gap), 0)

doc.recompute()
```

---

## 📚 知识小结

### 本课重点

1. ✅ 掌握了if条件判断的基本语法
2. ✅ 理解了模运算在奇偶判断中的应用
3. ✅ 学会了创建条件化的3D图案

### 关键语法

| 语法 | 说明 |
|:---|:---|
| `if 条件:` | 如果条件为真，执行缩进块 |
| `elif 条件:` | 否则如果条件为真 |
| `else:` | 否则（前面都不满足） |
| `条件1 and 条件2` | 两个条件都满足 |
| `条件1 or 条件2` | 至少一个满足 |
| `not 条件` | 条件取反 |

### 代码结构

```python
if 条件1:
    # 条件1为真时执行
elif 条件2:
    # 条件1为假且条件2为真时执行
else:
    # 前面所有条件都为假时执行
```

> ⚠️ **注意**：在写 if 语句时千万不要漏掉末尾的冒号 `:` ！

---

> **"条件判断让代码拥有了'思考'的能力！"** 🧠

---

<p align="center">
  <a href="#/module3/lesson07">下一课：数据的容器（List 列表与多段线）→</a>
</p>

# 📍 第 4 课：参数化思维（空间位置的向量控制）

> **"物体在三维空间中的平移，本质上是其各个顶点沿 X、Y、Z 轴的位移量叠加。"**

---

## 📐 物理/数理原理

### 空间向量（Vector）

在三维空间中，**向量**是描述位置、方向和位移的数学工具。

**向量的表示**：
$$\vec{v} = (x, y, z)$$

其中：
- $x$：沿X轴的位移（左右）
- $y$：沿Y轴的位移（前后）
- $z$：沿Z轴的位移（上下）

**向量的运算**：
- **加法**：$\vec{a} + \vec{b} = (a_x + b_x, a_y + b_y, a_z + b_z)$
- **数乘**：$k \cdot \vec{a} = (k \cdot a_x, k \cdot a_y, k \cdot a_z)$

> 💡 **物理意义**：当我们说"物体沿X轴移动50mm"，实际上是在物体的每个顶点坐标上加上向量 $(50, 0, 0)$。

---

## 💻 FreeCAD 脚本

### 基础向量操作

```python
import FreeCAD as App
import Part
from FreeCAD import Vector

doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()

# 创建一个正方体
box = Part.makeBox(10, 10, 10)
obj = doc.addObject("Part::Feature", "MovingBox")
obj.Shape = box

# 操控向量，让方块在 X 轴前进 50 毫米
obj.Placement.Base = Vector(50, 0, 0)

doc.recompute()

App.Console.PrintMessage(f"方块位置：{obj.Placement.Base}\n")
```

### 多点定位示例

```python
import FreeCAD as App
import Part
from FreeCAD import Vector

doc = App.ActiveDocument

# 创建多个方块，分别放在不同位置
positions = [
    Vector(0, 0, 0),      # 原点
    Vector(30, 0, 0),     # X轴方向
    Vector(0, 30, 0),     # Y轴方向
    Vector(0, 0, 30),     # Z轴方向
    Vector(30, 30, 30),   # 对角线方向
]

for i, pos in enumerate(positions):
    box = Part.makeBox(10, 10, 10)
    obj = doc.addObject("Part::Feature", f"Box_{i}")
    obj.Shape = box
    obj.Placement.Base = pos
    
    # 给不同位置的方块不同颜色
colors = [
    (1.0, 0.0, 0.0),  # 红色 - 原点
    (0.0, 1.0, 0.0),  # 绿色 - X轴
    (0.0, 0.0, 1.0),  # 蓝色 - Y轴
    (1.0, 1.0, 0.0),  # 黄色 - Z轴
    (1.0, 0.0, 1.0),  # 紫色 - 对角线
]
    obj.ViewObject.ShapeColor = colors[i]

doc.recompute()
```

---

## 📋 实验报告

### 观察记录

运行基础向量代码后：
1. ✅ 方块没有在原点生成
2. ✅ 方块精确地出现在了 X 轴 50mm 的位置
3. ✅ 控制台输出了当前的位置向量

### 向量探究实验

试着修改 `Vector(x, y, z)` 的参数：

| 向量 | 位置描述 |
|:---|:---|
| `Vector(0, 0, 0)` | 坐标原点 |
| `Vector(50, 0, 0)` | X轴正方向50mm |
| `Vector(-50, 0, 0)` | X轴负方向50mm |
| `Vector(0, 50, 0)` | Y轴正方向50mm |
| `Vector(0, 0, 50)` | Z轴正方向50mm（上方） |
| `Vector(30, 30, 30)` | 空间对角线方向 |

### 思考问题

1. 如何让两个方块紧密相邻（无间隙）？
2. 如何计算两个方块之间的距离？

---

## 🔧 制作指南

### 向量的运算

```python
from FreeCAD import Vector

# 创建向量
v1 = Vector(10, 20, 30)
v2 = Vector(5, 5, 5)

# 向量加法
v3 = v1 + v2    # 结果：(15, 25, 35)

# 向量减法
v4 = v1 - v2    # 结果：(5, 15, 25)

# 数乘
v5 = v1 * 2     # 结果：(20, 40, 60)

# 向量长度（模）
length = v1.Length    # 结果：约37.42

# 单位向量
unit = v1.normalize()  # 长度为1的向量

print(f"v1 + v2 = {v3}")
print(f"v1 - v2 = {v4}")
print(f"v1 * 2 = {v5}")
print(f"v1的长度 = {length}")
```

### 相对定位技巧

```python
import Part
from FreeCAD import Vector

doc = App.ActiveDocument

# 基础尺寸
box_size = 20
gap = 5  # 间隙

# 第一个方块
box1 = Part.makeBox(box_size, box_size, box_size)
obj1 = doc.addObject("Part::Feature", "Box1")
obj1.Shape = box1
obj1.Placement.Base = Vector(0, 0, 0)

# 第二个方块（紧挨着第一个）
box2 = Part.makeBox(box_size, box_size, box_size)
obj2 = doc.addObject("Part::Feature", "Box2")
obj2.Shape = box2
obj2.Placement.Base = Vector(box_size + gap, 0, 0)

# 第三个方块（基于第二个的位置）
box3 = Part.makeBox(box_size, box_size, box_size)
obj3 = doc.addObject("Part::Feature", "Box3")
obj3.Shape = box3
obj3.Placement.Base = obj2.Placement.Base + Vector(box_size + gap, 0, 0)

doc.recompute()
```

### 旋转控制

```python
import Part
from FreeCAD import Vector

doc = App.ActiveDocument

# 创建一个长方体
box = Part.makeBox(40, 10, 10)
obj = doc.addObject("Part::Feature", "RotatedBox")
obj.Shape = box

# 设置位置
obj.Placement.Base = Vector(0, 0, 0)

# 设置旋转（绕Z轴旋转45度）
obj.Placement.Rotation.Axis = Vector(0, 0, 1)  # 绕Z轴
obj.Placement.Rotation.Angle = 3.14159 / 4      # 45度（弧度制）

doc.recompute()
```

---

## 🎯 课后挑战

### 挑战1：创建3D坐标轴

用三个不同颜色的圆柱体表示X、Y、Z轴：

```python
import Part
from FreeCAD import Vector
import math

doc = App.ActiveDocument

axis_length = 100
axis_radius = 2

# X轴 - 红色
x_axis = Part.makeCylinder(axis_radius, axis_length)
x_obj = doc.addObject("Part::Feature", "X_Axis")
x_obj.Shape = x_axis
x_obj.Placement.Base = Vector(0, 0, 0)
x_obj.Placement.Rotation.Axis = Vector(0, 1, 0)  # 绕Y轴旋转90度
x_obj.Placement.Rotation.Angle = -math.pi / 2
x_obj.ViewObject.ShapeColor = (1.0, 0.0, 0.0)

# Y轴 - 绿色
y_axis = Part.makeCylinder(axis_radius, axis_length)
y_obj = doc.addObject("Part::Feature", "Y_Axis")
y_obj.Shape = y_axis
y_obj.Placement.Base = Vector(0, 0, 0)
y_obj.Placement.Rotation.Axis = Vector(1, 0, 0)  # 绕X轴旋转90度
y_obj.Placement.Rotation.Angle = math.pi / 2
y_obj.ViewObject.ShapeColor = (0.0, 1.0, 0.0)

# Z轴 - 蓝色
z_axis = Part.makeCylinder(axis_radius, axis_length)
z_obj = doc.addObject("Part::Feature", "Z_Axis")
z_obj.Shape = z_axis
z_obj.Placement.Base = Vector(0, 0, 0)
z_obj.ViewObject.ShapeColor = (0.0, 0.0, 1.0)

doc.recompute()
```

### 挑战2：创建金字塔堆叠

创建3层方块金字塔：

```python
import Part
from FreeCAD import Vector

doc = App.ActiveDocument

box_size = 20
gap = 2

for layer in range(3):  # 3层
    # 每层方块数量：底层3x3，中层2x2，顶层1x1
    count = 3 - layer
    z = layer * (box_size + gap)
    
    for x in range(count):
        for y in range(count):
            box = Part.makeBox(box_size, box_size, box_size)
            obj = doc.addObject("Part::Feature", f"Layer{layer}_Box{x}_{y}")
            obj.Shape = box
            
            # 计算位置（居中）
            offset_x = (3 - count) * (box_size + gap) / 2
            offset_y = (3 - count) * (box_size + gap) / 2
            
            pos_x = x * (box_size + gap) + offset_x
            pos_y = y * (box_size + gap) + offset_y
            
            obj.Placement.Base = Vector(pos_x, pos_y, z)

doc.recompute()
```

---

## 📚 知识小结

### 本课重点

1. ✅ 理解了空间向量的概念
2. ✅ 掌握了使用Vector控制物体位置
3. ✅ 学会了物体的旋转控制

### 关键API

| 代码 | 功能 |
|:---|:---|
| `Vector(x, y, z)` | 创建三维向量 |
| `obj.Placement.Base` | 设置物体位置 |
| `obj.Placement.Rotation.Axis` | 设置旋转轴 |
| `obj.Placement.Rotation.Angle` | 设置旋转角度（弧度） |

### 弧度与角度转换

```python
import math

# 角度转弧度
radians = math.radians(45)    # 45度 → 0.785弧度

# 弧度转角度
degrees = math.degrees(3.14159)  # 3.14159弧度 → 180度
```

---

> **"Vector(X, Y, Z) 是我们以后控制机械臂或零件装配最核心的数学工具。"** 🎯

---

<p align="center">
  <a href="#/module2/lesson05">下一课：秩序的阵列（for 循环与线性构建）→</a>
</p>

# 📍 第 5 课：秩序的阵列（for 循环与线性构建）

> **"利用循环变量，每次乘以固定的步长，即可在空间中生成均匀排列的结构。"**

---

## 📐 物理/数理原理

### 等差数列与空间平移

**等差数列**：每一项与前一项的差是一个常数（公差）。

$$a_n = a_1 + (n-1) \cdot d$$

其中：
- $a_n$：第n项
- $a_1$：首项
- $d$：公差

**空间映射**：
将等差数列映射到三维空间的坐标上：
- X坐标：$x_i = i \cdot \Delta x$
- Y坐标：$y_i = i \cdot \Delta y$
- Z坐标：$z_i = i \cdot \Delta z$

> 💡 **应用场景**：阶梯、栅栏、齿条、货架等均匀排列的结构。

---

## 💻 FreeCAD 脚本

### 基础for循环

```python
import FreeCAD as App
import Part
from FreeCAD import Vector

doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()

# 用 for 循环建造 5 级台阶
for i in range(5):
    step = Part.makeBox(20, 10, 2)
    obj = doc.addObject("Part::Feature", f"Step_{i}")
    obj.Shape = step
    
    # 高度(Z)和深度(Y)随 i 递增
    obj.Placement.Base = Vector(0, i*10, i*2)
    
    # 给每级台阶不同颜色
    color_intensity = i / 4.0  # 0.0 到 1.0
    obj.ViewObject.ShapeColor = (color_intensity, 0.5, 1.0 - color_intensity)

doc.recompute()

App.Console.PrintMessage("5级台阶建造完成！\n")
```

### range()函数详解

```python
# range(stop) - 从0到stop-1
for i in range(5):
    print(i)  # 输出: 0, 1, 2, 3, 4

# range(start, stop) - 从start到stop-1
for i in range(2, 7):
    print(i)  # 输出: 2, 3, 4, 5, 6

# range(start, stop, step) - 带步长
for i in range(0, 10, 2):
    print(i)  # 输出: 0, 2, 4, 6, 8
```

---

## 📋 实验报告

### 观察记录

运行台阶代码后：
1. ✅ 代码运行瞬间，5 级台阶如同多米诺骨牌一样精准排列
2. ✅ 每级台阶在Y轴方向前进10mm，在Z轴方向上升2mm
3. ✅ 台阶颜色从蓝色渐变到紫色

### 循环变量追踪

| i值 | Y位置 (i*10) | Z位置 (i*2) | 说明 |
|:---:|:---:|:---:|:---|
| 0 | 0 | 0 | 第一级（最底层） |
| 1 | 10 | 2 | 第二级 |
| 2 | 20 | 4 | 第三级 |
| 3 | 30 | 6 | 第四级 |
| 4 | 40 | 8 | 第五级（最高层） |

### 思考问题

1. 如何创建10级台阶？
2. 如何让台阶向X轴方向延伸？
3. 如何让每级台阶高度递增更多？

---

## 🔧 制作指南

### Python缩进规则

> ⚠️ **注意**：Python是靠缩进认"一家人"的！

```python
# ✅ 正确：循环内部的代码缩进4个空格
for i in range(5):
    # 这行在循环内部
    print(i)
    # 这行也在循环内部
    Part.show(box)
# 这行在循环外部（不缩进）
print("循环结束")

# ❌ 错误：不要混用Tab和空格！
# 建议：统一使用4个空格
```

### 嵌套循环（二维阵列）

```python
import Part
from FreeCAD import Vector

doc = App.ActiveDocument

# 创建3x3的方块阵列
rows = 3
cols = 3
box_size = 15
gap = 5

for row in range(rows):
    for col in range(cols):
        box = Part.makeBox(box_size, box_size, box_size)
        obj = doc.addObject("Part::Feature", f"Box_R{row}_C{col}")
        obj.Shape = box
        
        # 计算位置
        x = col * (box_size + gap)
        y = row * (box_size + gap)
        obj.Placement.Base = Vector(x, y, 0)
        
        # 根据位置设置颜色
        red = col / (cols - 1) if cols > 1 else 0.5
        green = row / (rows - 1) if rows > 1 else 0.5
        obj.ViewObject.ShapeColor = (red, green, 0.5)

doc.recompute()
```

### 圆形阵列

```python
import Part
from FreeCAD import Vector
import math

doc = App.ActiveDocument

# 圆形阵列参数
count = 12      # 数量
radius = 50     # 半径
box_size = 8

for i in range(count):
    # 计算角度（弧度）
    angle = 2 * math.pi * i / count
    
    # 计算位置
    x = radius * math.cos(angle)
    y = radius * math.sin(angle)
    
    # 创建方块
    box = Part.makeBox(box_size, box_size, box_size)
    obj = doc.addObject("Part::Feature", f"CircleBox_{i}")
    obj.Shape = box
    obj.Placement.Base = Vector(x, y, 0)
    
    # 让方块朝向圆心
    obj.Placement.Rotation.Axis = Vector(0, 0, 1)
    obj.Placement.Rotation.Angle = angle

doc.recompute()
```

---

## 🎯 课后挑战

### 挑战1：创建螺旋楼梯

```python
import Part
from FreeCAD import Vector
import math

doc = App.ActiveDocument

# 螺旋楼梯参数
steps = 20          # 台阶数
stair_radius = 40   # 楼梯半径
step_height = 5     # 每级高度
step_angle = 15     # 每级角度（度）

for i in range(steps):
    # 创建台阶
    step = Part.makeBox(15, 8, 2)
    obj = doc.addObject("Part::Feature", f"SpiralStep_{i}")
    obj.Shape = step
    
    # 计算角度（弧度）
    angle_rad = math.radians(i * step_angle)
    
    # 计算位置
    x = stair_radius * math.cos(angle_rad)
    y = stair_radius * math.sin(angle_rad)
    z = i * step_height
    
    obj.Placement.Base = Vector(x, y, z)
    
    # 旋转台阶朝向圆心
    obj.Placement.Rotation.Axis = Vector(0, 0, 1)
    obj.Placement.Rotation.Angle = angle_rad + math.pi/2

doc.recompute()
```

### 挑战2：创建金字塔形堆叠

```python
import Part
from FreeCAD import Vector

doc = App.ActiveDocument

box_size = 10
gap = 2
layers = 5  # 层数

for layer in range(layers):
    # 每层是一个正方形，边长递减
    boxes_in_layer = layers - layer  # 5, 4, 3, 2, 1
    z = layer * (box_size + gap)
    
    for x in range(boxes_in_layer):
        for y in range(boxes_in_layer):
            box = Part.makeBox(box_size, box_size, box_size)
            obj = doc.addObject("Part::Feature", f"Layer{layer}_{x}_{y}")
            obj.Shape = box
            
            # 居中偏移
            offset = (layers - boxes_in_layer) * (box_size + gap) / 2
            
            pos_x = x * (box_size + gap) + offset
            pos_y = y * (box_size + gap) + offset
            
            obj.Placement.Base = Vector(pos_x, pos_y, z)

doc.recompute()
```

---

## 📚 知识小结

### 本课重点

1. ✅ 掌握了for循环的基本语法
2. ✅ 理解了等差数列与空间排列的关系
3. ✅ 学会了创建一维、二维和圆形阵列

### 关键语法

| 语法 | 说明 |
|:---|:---|
| `for i in range(n)` | 循环n次，i从0到n-1 |
| `for i in range(a, b)` | i从a到b-1 |
| `for i in range(a, b, s)` | i从a到b-1，步长为s |
| `f"Step_{i}"` | f-string格式化字符串 |

### 嵌套循环结构

```python
for 外层变量 in range(外层次数):
    for 内层变量 in range(内层次数):
        # 内层循环体
    # 外层循环体
```

---

> **"循环是编程的魔法，让重复的工作瞬间完成！"** 🔄

---

<p align="center">
  <a href="#/module2/lesson06">下一课：逻辑岔路口（if 条件判断与间隔挖空）→</a>
</p>

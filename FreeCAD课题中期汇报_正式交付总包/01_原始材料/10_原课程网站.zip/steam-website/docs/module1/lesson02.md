# 📍 第 2 课：初探FreeCAD（代码召唤几何体）

> **"任何复杂的三维物体，都可以被拆解为最基础的拓扑几何体。"**

---

## 📐 物理/数理原理

### 拓扑几何体基础

在数学和计算机图形学中，**任何复杂的三维物体都可以被拆解为最基础的拓扑几何体**。这是3D建模的核心思想。

**基础几何体及其参数**：

| 几何体 | 决定参数 | 数学描述 |
|:---|:---|:---|
| **正方体** | 长、宽、高 | $V = l \times w \times h$ |
| **球体** | 半径 $r$ | $V = \frac{4}{3}\pi r^3$ |
| **圆柱体** | 半径 $r$、高度 $h$ | $V = \pi r^2 h$ |
| **圆锥体** | 底面半径 $r$、高度 $h$ | $V = \frac{1}{3}\pi r^2 h$ |

> 💡 **拓扑学概念**：拓扑学研究的是物体在连续变形下保持不变的性质。一个球体无论如何拉伸（不撕裂），其拓扑性质不变。

---

## 💻 FreeCAD 脚本

让我们在坐标原点 (0,0,0) 召唤一个基础球体：

```python
import FreeCAD as App
import Part

# 确保有活动文档
doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()

# 在坐标原点 (0,0,0) 召唤一个半径为 10 的基础球体
my_sphere = Part.makeSphere(10)

# 将球体显示在3D视图中
Part.show(my_sphere)

# 刷新视觉缓存
doc.recompute()

App.Console.PrintMessage("球体生成成功！半径：10mm\n")
```

### 更多基础几何体代码

```python
import Part

# 正方体：长20、宽10、高5
box = Part.makeBox(20, 10, 5)
Part.show(box)

# 圆柱体：半径8、高度20
cylinder = Part.makeCylinder(8, 20)
Part.show(cylinder)

# 圆锥体：底面半径10、顶面半径0（尖的）、高度15
cone = Part.makeCone(10, 0, 15)
Part.show(cone)

# 圆环体：半径15、管道半径3
torus = Part.makeTorus(15, 3)
Part.show(torus)
```

---

## 📋 实验报告

### 观察记录

运行球体代码后：
1. ✅ 屏幕中央瞬间生成了一个灰色的标准球体
2. ✅ 球体位于坐标原点 (0,0,0)
3. ✅ 在左侧的组合浏览器中可以看到新创建的对象

### 参数探究

试着修改 `Part.makeSphere(10)` 中的参数：

| 参数值 | 效果 |
|:---|:---|
| `5` | 生成一个更小的球体 |
| `20` | 生成一个更大的球体 |
| `50` | 生成一个巨大的球体（可能需要缩放视图才能看到全貌） |

### 思考问题

1. 如果参数改为负数会发生什么？试试看！
2. 如何同时生成多个不同大小的球体？

---

## 🔧 制作指南

### 3D 视图操控技巧

| 操作 | 方法 |
|:---|:---|
| **旋转视角** | 按住 `Shift` 键 + 鼠标右键拖动 |
| **平移视角** | 按住 `Shift` 键 + 鼠标中键拖动 |
| **缩放视图** | 滚动鼠标滚轮 |
| **适应视图** | 按 `Ctrl` + `1`（或点击工具栏的适应视图按钮） |

### 隐藏/显示对象

在左侧的组合浏览器中：
- 点击对象旁边的 **眼睛图标** 可以隐藏/显示对象
- 点击 **空格键** 也可以快速切换选中对象的可见性

### 修改对象颜色

```python
# 获取最后一个创建的对象
obj = App.ActiveDocument.ActiveObject

# 设置为红色 (R, G, B)
obj.ViewObject.ShapeColor = (1.0, 0.0, 0.0)

# 其他颜色示例：
# 绿色：(0.0, 1.0, 0.0)
# 蓝色：(0.0, 0.0, 1.0)
# 黄色：(1.0, 1.0, 0.0)
# 紫色：(1.0, 0.0, 1.0)
```

---

## 🎯 课后挑战

### 挑战1：彩虹几何体

创建三个不同颜色、不同类型的几何体：

```python
import Part

doc = App.ActiveDocument

# 红色正方体
box = Part.makeBox(10, 10, 10)
box_obj = doc.addObject("Part::Feature", "RedBox")
box_obj.Shape = box
box_obj.ViewObject.ShapeColor = (1.0, 0.0, 0.0)

# 绿色球体
sphere = Part.makeSphere(8)
sphere_obj = doc.addObject("Part::Feature", "GreenSphere")
sphere_obj.Shape = sphere
sphere_obj.ViewObject.ShapeColor = (0.0, 1.0, 0.0)

# 蓝色圆柱体
cylinder = Part.makeCylinder(5, 15)
cyl_obj = doc.addObject("Part::Feature", "BlueCylinder")
cyl_obj.Shape = cylinder
cyl_obj.ViewObject.ShapeColor = (0.0, 0.0, 1.0)

doc.recompute()
```

### 挑战2：探索更多形状

查阅 FreeCAD 文档，尝试创建以下形状：
- `Part.makeTube(radius, height, thickness)` - 管道
- `Part.makeWedge(xmin, ymin, zmin, ...) ` - 楔形

---

## 📚 知识小结

### 本课重点

1. ✅ 掌握了基础几何体的创建方法
2. ✅ 学会了控制3D视图的视角
3. ✅ 了解了如何修改对象颜色

### 关键API

| 函数 | 功能 |
|:---|:---|
| `Part.makeSphere(radius)` | 创建球体 |
| `Part.makeBox(l, w, h)` | 创建正方体 |
| `Part.makeCylinder(r, h)` | 创建圆柱体 |
| `Part.makeCone(r1, r2, h)` | 创建圆锥体 |
| `Part.makeTorus(r, tr)` | 创建圆环体 |
| `Part.show(shape)` | 显示形状 |
| `doc.recompute()` | 刷新视图 |

---

> **"从最简单的几何体开始，你将构建整个世界。"** 🌍

---

<p align="center">
  <a href="#/module2/lesson03">下一课：控制台的魔法（Python变量的引入）→</a>
</p>

# 📍 第 20 课：智造发布会（答辩、开源与反思）

> **"将代码分享给他人，探讨算法的优劣，是计算机科学推动人类进步的动力。"**

---

## 📐 物理/数理原理

### 开源文化（Open Source）

**开源**是指将软件的源代码公开，允许他人查看、使用、修改和分发。

**开源的意义**：
- **知识共享**：让更多人学习和进步
- **协作创新**：集思广益，共同改进
- **透明可信**：代码公开，质量可验证
- **社区成长**：形成良性循环的生态系统

**开源协议**：
- **MIT**：最宽松，允许商业使用
- **GPL**：要求衍生作品也开源
- **CC BY-NC**：非商业使用

> 💡 **著名开源项目**：Linux、Python、FreeCAD、Arduino

---

## 💻 FreeCAD 脚本

### 项目总结代码模板

```python
"""
================================================================
项目名称：参数化齿轮传动教具
作者：东台中学 STEAM 创客组
日期：2026-03-08
版本：1.0

项目描述：
    利用 math.cos 和 QSlider 实现齿轮啮合动画与参数调节
    可用于物理课上的机械传动原理演示

核心技术：
    - Python 面向对象编程
    - FreeCAD Part 模块
    - PySide GUI 开发
    - QTimer 动画控制

使用说明：
    1. 在 FreeCAD 中打开 Python 控制台
    2. 复制粘贴本代码
    3. 运行后即可看到控制面板
    4. 通过滑动条调节齿轮参数

开源协议：MIT License
================================================================
"""

import FreeCAD as App
import Part
from PySide import QtCore, QtGui
from FreeCAD import Vector
import math

class GearTransmissionDemo(QtGui.QWidget):
    """
    齿轮传动演示系统
    
    功能：
        - 双齿轮啮合动画
        - 实时参数调节
        - 速度控制
    """
    
    def __init__(self):
        super().__init__()
        self.angle1 = 0
        self.angle2 = 0
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.update_animation)
        self.initUI()
        self.setup_objects()
    
    def initUI(self):
        """初始化用户界面"""
        self.setWindowTitle("⚙️ 齿轮传动演示 - 东台中学STEAM项目")
        self.setGeometry(300, 300, 400, 200)
        
        layout = QtGui.QVBoxLayout()
        
        # 标题
        title = QtGui.QLabel("齿轮传动原理演示")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #3F51B5;")
        title.setAlignment(QtGui.Qt.AlignCenter)
        layout.addWidget(title)
        
        # 速度控制
        speed_layout = QtGui.QHBoxLayout()
        speed_layout.addWidget(QtGui.QLabel("转速:"))
        self.speed_slider = QtGui.QSlider(QtCore.Qt.Horizontal)
        self.speed_slider.setRange(1, 10)
        self.speed_slider.setValue(3)
        speed_layout.addWidget(self.speed_slider)
        layout.addLayout(speed_layout)
        
        # 按钮
        btn_layout = QtGui.QHBoxLayout()
        
        self.start_btn = QtGui.QPushButton("▶️ 启动")
        self.start_btn.clicked.connect(self.start)
        self.start_btn.setStyleSheet("background-color: #4CAF50; color: white;")
        
        self.stop_btn = QtGui.QPushButton("⏸️ 停止")
        self.stop_btn.clicked.connect(self.stop)
        self.stop_btn.setStyleSheet("background-color: #f44336; color: white;")
        
        btn_layout.addWidget(self.start_btn)
        btn_layout.addWidget(self.stop_btn)
        
        layout.addLayout(btn_layout)
        
        # 状态显示
        self.status_label = QtGui.QLabel("就绪 - 等待启动")
        self.status_label.setAlignment(QtGui.Qt.AlignCenter)
        layout.addWidget(self.status_label)
        
        self.setLayout(layout)
        self.show()
    
    def setup_objects(self):
        """创建3D对象"""
        self.doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()
        
        # 主动轮（大齿轮）
        gear1 = Part.makeCylinder(30, 8)
        self.gear1_obj = self.doc.addObject("Part::Feature", "DrivingGear")
        self.gear1_obj.Shape = gear1
        self.gear1_obj.Placement.Base = Vector(-40, 0, 0)
        self.gear1_obj.ViewObject.ShapeColor = (0.9, 0.7, 0.2)
        
        # 从动轮（小齿轮）
        gear2 = Part.makeCylinder(15, 8)
        self.gear2_obj = self.doc.addObject("Part::Feature", "DrivenGear")
        self.gear2_obj.Shape = gear2
        self.gear2_obj.Placement.Base = Vector(25, 0, 0)
        self.gear2_obj.ViewObject.ShapeColor = (0.2, 0.7, 0.9)
        
        # 中心轴
        shaft1 = Part.makeCylinder(5, 12)
        shaft1_obj = self.doc.addObject("Part::Feature", "Shaft1")
        shaft1_obj.Shape = shaft1
        shaft1_obj.Placement.Base = Vector(-40, 0, -2)
        shaft1_obj.ViewObject.ShapeColor = (0.5, 0.5, 0.5)
        
        shaft2 = Part.makeCylinder(4, 12)
        shaft2_obj = self.doc.addObject("Part::Feature", "Shaft2")
        shaft2_obj.Shape = shaft2
        shaft2_obj.Placement.Base = Vector(25, 0, -2)
        shaft2_obj.ViewObject.ShapeColor = (0.5, 0.5, 0.5)
        
        self.doc.recompute()
    
    def update_animation(self):
        """更新动画"""
        speed = self.speed_slider.value()
        
        # 主动轮旋转
        self.angle1 += speed
        if self.angle1 >= 360:
            self.angle1 -= 360
        
        # 从动轮反向旋转（速度比 = 半径比 = 2:1）
        self.angle2 -= speed * 2
        if self.angle2 <= -360:
            self.angle2 += 360
        
        # 应用旋转
        self.gear1_obj.Placement.Rotation.Axis = Vector(0, 0, 1)
        self.gear1_obj.Placement.Rotation.Angle = math.radians(self.angle1)
        
        self.gear2_obj.Placement.Rotation.Axis = Vector(0, 0, 1)
        self.gear2_obj.Placement.Rotation.Angle = math.radians(self.angle2)
        
        self.doc.recompute()
    
    def start(self):
        """开始动画"""
        self.timer.start(50)
        self.status_label.setText("运行中...")
        self.status_label.setStyleSheet("color: green;")
    
    def stop(self):
        """停止动画"""
        self.timer.stop()
        self.status_label.setText("已停止")
        self.status_label.setStyleSheet("color: orange;")

# 启动演示
demo = GearTransmissionDemo()

App.Console.PrintMessage("=" * 50 + "\n")
App.Console.PrintMessage("齿轮传动演示系统已启动！\n")
App.Console.PrintMessage("作者：东台中学 STEAM 创客组\n")
App.Console.PrintMessage("=" * 50 + "\n")
```

---

## 📋 实验报告

### 项目答辩准备

**答辩内容**：
1. **项目介绍**：项目名称、目标、创新点
2. **技术方案**：使用的技术、实现方法
3. **演示展示**：现场演示GUI和3D模型
4. **成果展示**：3D打印实物
5. **反思总结**：遇到的问题、解决方法、收获

**答辩评分标准**：

| 评分项 | 占比 | 说明 |
|:---|:---:|:---|
| 功能实现 | 30% | 代码是否正常运行 |
| 创新性 | 20% | 设计是否有新意 |
| 技术难度 | 20% | 使用的技术复杂度 |
| 展示效果 | 15% | 演示是否清晰流畅 |
| 团队协作 | 15% | 分工是否合理 |

### 思考问题

1. 你的项目最大的创新点是什么？
2. 在开发过程中遇到的最大困难是什么？如何解决的？
3. 如果给你更多时间，你会如何改进项目？

---

## 🔧 制作指南

### 项目文档模板

```markdown
# 项目名称：XXX

## 1. 项目概述
- 项目背景
- 项目目标
- 应用场景

## 2. 技术方案
- 开发环境
- 核心技术
- 架构设计

## 3. 使用说明
- 安装步骤
- 操作方法
- 注意事项

## 4. 功能展示
- 功能列表
- 截图/视频
- 实物照片

## 5. 开发过程
- 时间规划
- 遇到的问题
- 解决方案

## 6. 总结反思
- 收获与成长
- 改进方向
- 感谢致辞

## 附录
- 源代码
- 参考文献
- 开源协议
```

### 代码分享平台

**GitHub/Gitee**：
1. 注册账号
2. 创建仓库
3. 上传代码
4. 编写README
5. 分享链接

**代码分享示例**：
```
仓库地址：https://gitee.com/yourname/steam-project

README内容：
- 项目简介
- 功能特点
- 安装说明
- 使用教程
- 截图展示
- 开源协议
```

---

## 🎯 课后挑战

### 挑战1：完善项目文档

为你的项目编写完整的文档，包括：
- 项目介绍
- 技术说明
- 使用教程
- 心得体会

### 挑战2：准备项目答辩

准备5分钟的答辩PPT，包含：
1. 封面（项目名称、作者）
2. 项目背景
3. 技术方案
4. 功能演示
5. 成果展示
6. 总结反思

---

## 📚 知识小结

### 本课重点

1. ✅ 理解了开源文化的意义
2. ✅ 掌握了项目文档编写方法
3. ✅ 学会了项目答辩准备

### 开源精神

```
分享 → 学习 → 改进 → 再分享
```

### 项目交付清单

- [ ] 源代码（带注释）
- [ ] 项目文档
- [ ] 使用说明
- [ ] 演示视频
- [ ] 3D打印实物
- [ ] 答辩PPT

> **在提交课题结题报告时，截取 GUI 面板与对应的 3D 渲染图，重点陈述"为何选用此数学模型"以及"遇到报错时如何 Debug"。**

---

> **"代码造物之旅，才刚刚开始！"** 🚀

---

<p align="center">
  <strong>🎉 恭喜你完成了全部20节课的学习！</strong>
</p>

<p align="center">
  <a href="#/README">🏠 返回首页</a>
</p>

# 📍 第 18 课：项目蓝图（需求分析与程序架构）

> **"在写代码前，利用伪代码规划数据结构、UI界面和3D生成逻辑的关联。"**

---

## 📐 物理/数理原理

### 软件工程与系统设计

**软件工程**是将系统化、规范化、可量化的方法应用于软件开发的过程。

**开发流程**：
1. **需求分析**：明确要做什么
2. **系统设计**：规划怎么做
3. **编码实现**：写代码
4. **测试验证**：检查对不对
5. **部署维护**：交付使用

**伪代码（Pseudocode）**：
- 介于自然语言和编程语言之间
- 描述算法逻辑，不关注语法细节
- 帮助理清思路，避免"缩进地狱"

> 💡 **实际应用**：任何复杂的软件项目都需要先规划再实现，这是专业开发者的基本素养。

---

## 💻 FreeCAD 脚本

### 项目伪代码示例

```python
# ============================================================
# 【STEAM 终极项目伪代码：参数化笔筒生成器】
# ============================================================
# 
# 项目名称：智能参数化笔筒
# 作者：东台中学 STEAM 创客组
# 功能：通过GUI界面自定义笔筒的尺寸、形状和分隔
#
# ============================================================

# ------------------------------------------------------------
# 1. 导入模块
# ------------------------------------------------------------
# import FreeCAD as App
# import Part
# from PySide import QtCore, QtGui
# from FreeCAD import Vector

# ------------------------------------------------------------
# 2. 设计 UI 类
# ------------------------------------------------------------
# class PenHolderUI(QtGui.QWidget):
#     def __init__(self):
#         # 初始化窗口
#         # 创建输入控件：
#         #   - 外半径输入框
#         #   - 高度输入框
#         #   - 分隔数量滑动条
#         #   - 壁厚输入框
#         #   - 生成按钮
#         #   - 预览按钮
#     
#     def initUI(self):
#         # 设置窗口标题和大小
#         # 创建网格布局
#         # 添加控件到布局
# 
#     def generate(self):
#         # 获取UI参数
#         # 调用 generate_holder 函数
#         # 显示成功信息

# ------------------------------------------------------------
# 3. 定义核心生成函数
# ------------------------------------------------------------
# def generate_holder(outer_radius, height, divisions, thickness):
#     """
#     生成参数化笔筒
#     
#     参数:
#         outer_radius: 外半径
#         height: 高度
#         divisions: 分隔数量
#         thickness: 壁厚
#     
#     返回:
#         笔筒的Shape对象
#     """
#     
#     # 步骤 a: 生成外层多边形柱体
#     # outer = Part.makeCylinder(outer_radius, height)
#     
#     # 步骤 b: 生成内层挖空柱体
#     # inner_radius = outer_radius - thickness
#     # inner = Part.makeCylinder(inner_radius, height)
#     
#     # 步骤 c: 执行布尔相减 (outer.cut(inner))
#     # hollow_cylinder = outer.cut(inner)
#     
#     # 步骤 d: 如果 divisions > 0，添加分隔板
#     # if divisions > 0:
#     #     for i in range(divisions):
#     #         angle = 360 / divisions * i
#     #         divider = create_divider(inner_radius, height, thickness, angle)
#     #         hollow_cylinder = hollow_cylinder.fuse(divider)
#     
#     # 步骤 e: 返回最终结果
#     # return hollow_cylinder

# ------------------------------------------------------------
# 4. 辅助函数
# ------------------------------------------------------------
# def create_divider(radius, height, thickness, angle):
#     """创建单个分隔板"""
#     # 创建一个长方体作为分隔板
#     # 旋转到指定角度
#     # 返回分隔板的Shape

# ------------------------------------------------------------
# 5. 主程序入口
# ------------------------------------------------------------
# if __name__ == "__main__":
#     # 创建UI实例
#     # ui = PenHolderUI()
#     # 显示窗口
#     # ui.show()

# ============================================================
```

### 实际实现

```python
import FreeCAD as App
import Part
from PySide import QtCore, QtGui
from FreeCAD import Vector
import math

class PenHolderUI(QtGui.QWidget):
    """参数化笔筒生成器"""
    
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        self.setWindowTitle("🖊️ 参数化笔筒生成器")
        self.setGeometry(300, 300, 400, 300)
        
        layout = QtGui.QFormLayout()
        
        # 参数输入
        self.radius_input = QtGui.QLineEdit("30")
        self.height_input = QtGui.QLineEdit("80")
        self.thickness_input = QtGui.QLineEdit("3")
        
        self.divisions_slider = QtGui.QSlider(QtCore.Qt.Horizontal)
        self.divisions_slider.setRange(0, 6)
        self.divisions_slider.setValue(0)
        self.divisions_label = QtGui.QLabel("0")
        self.divisions_slider.valueChanged.connect(
            lambda v: self.divisions_label.setText(str(v))
        )
        
        # 按钮
        self.generate_btn = QtGui.QPushButton("✨ 生成笔筒")
        self.generate_btn.clicked.connect(self.generate)
        self.generate_btn.setStyleSheet("background-color: #4CAF50; color: white; padding: 10px;")
        
        # 添加到布局
        layout.addRow("外半径 (mm):", self.radius_input)
        layout.addRow("高度 (mm):", self.height_input)
        layout.addRow("壁厚 (mm):", self.thickness_input)
        layout.addRow("分隔数量:", self.divisions_slider)
        layout.addRow("", self.divisions_label)
        layout.addRow(self.generate_btn)
        
        self.setLayout(layout)
        self.show()
    
    def generate(self):
        try:
            radius = float(self.radius_input.text())
            height = float(self.height_input.text())
            thickness = float(self.thickness_input.text())
            divisions = self.divisions_slider.value()
            
            doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()
            
            # 创建外层圆柱
            outer = Part.makeCylinder(radius, height)
            
            # 创建内层圆柱（挖空）
            inner_radius = radius - thickness
            if inner_radius > 0:
                inner = Part.makeCylinder(inner_radius, height)
                holder = outer.cut(inner)
            else:
                holder = outer
            
            # 添加分隔板
            if divisions > 0 and inner_radius > 0:
                for i in range(divisions):
                    angle = 2 * math.pi * i / divisions
                    
                    # 创建分隔板
                    divider = Part.makeBox(inner_radius, thickness, height)
                    
                    # 旋转到正确角度
                    divider.rotate(Vector(0, 0, 0), Vector(0, 0, 1), math.degrees(angle))
                    
                    # 合并到笔筒
                    holder = holder.fuse(divider)
            
            # 显示结果
            obj = doc.addObject("Part::Feature", "PenHolder")
            obj.Shape = holder
            obj.ViewObject.ShapeColor = (0.3, 0.6, 0.9)
            
            doc.recompute()
            
            QtGui.QMessageBox.information(self, "成功", "笔筒生成完成！")
            
        except ValueError:
            QtGui.QMessageBox.critical(self, "错误", "请输入有效的数字！")

# 启动
penholder_gui = PenHolderUI()
```

---

## 📋 实验报告

### 观察记录

通过书写伪代码：
1. ✅ 理清了参数传递的逻辑
2. ✅ 避免了在复杂开发中出现"缩进地狱"
3. ✅ 变量未定义等错误在编码前就得到了预防

### 伪代码 vs 实际代码

| 阶段 | 特点 | 目的 |
|:---|:---|:---|
| 伪代码 | 自然语言描述，无语法要求 | 理清思路 |
| 实际代码 | 严格的语法，可执行 | 实现功能 |

### 思考问题

1. 为什么需要先写伪代码再写实际代码？
2. 如何评估一个程序架构的好坏？
3. 大型软件项目是如何分工协作的？

---

## 🔧 制作指南

### 项目规划清单

```markdown
## 项目规划清单

### 1. 需求分析
- [ ] 明确项目目标
- [ ] 列出功能需求
- [ ] 确定用户群体
- [ ] 评估技术可行性

### 2. 系统设计
- [ ] 绘制系统架构图
- [ ] 设计数据流程
- [ ] 规划UI界面
- [ ] 编写伪代码

### 3. 开发实现
- [ ] 搭建开发环境
- [ ] 编写核心代码
- [ ] 实现UI界面
- [ ] 集成测试

### 4. 测试验证
- [ ] 功能测试
- [ ] 性能测试
- [ ] 用户测试
- [ ] Bug修复

### 5. 部署交付
- [ ] 编写使用文档
- [ ] 打包发布
- [ ] 用户培训
- [ ] 后续维护
```

### 代码规范

```python
"""
模块文档字符串

描述模块的功能、作者、版本等信息
"""

import FreeCAD as App
import Part

# 常量定义（大写）
DEFAULT_RADIUS = 10.0
MAX_HEIGHT = 500.0

def create_cylinder(radius, height):
    """
    创建圆柱体
    
    参数:
        radius (float): 圆柱半径，单位mm
        height (float): 圆柱高度，单位mm
    
    返回:
        Part.Shape: 圆柱体的形状对象
    
    示例:
        >>> cyl = create_cylinder(10, 20)
    """
    # 参数验证
    if radius <= 0:
        raise ValueError("半径必须大于0")
    
    if height <= 0 or height > MAX_HEIGHT:
        raise ValueError(f"高度必须在0-{MAX_HEIGHT}之间")
    
    # 创建圆柱
    cylinder = Part.makeCylinder(radius, height)
    
    return cylinder

class MyWidget(QtGui.QWidget):
    """
    自定义窗口类
    
    属性:
        radius_input (QLineEdit): 半径输入框
    """
    
    def __init__(self):
        """初始化窗口"""
        super().__init__()
        self.initUI()
```

---

## 🎯 课后挑战

### 挑战1：设计一个完整的项目方案

为以下项目编写完整的伪代码：

```python
# 项目名称：参数化花瓶生成器
# 功能：
#   1. 可以设置花瓶的高度、最大直径、瓶口直径
#   2. 可以选择不同的轮廓曲线（直线、弧线、S形）
#   3. 可以设置壁厚
#   4. 可以预览和生成3D模型
#   5. 可以导出STL文件

# 请在此处编写伪代码...
```

---

## 📚 知识小结

### 本课重点

1. ✅ 理解了软件开发的基本流程
2. ✅ 掌握了伪代码的编写方法
3. ✅ 学会了项目规划和架构设计

### 开发流程

```
需求分析 → 系统设计 → 编码实现 → 测试验证 → 部署交付
```

### 伪代码的作用

1. **理清思路**：在编码前明确逻辑
2. **便于沟通**：团队成员可以理解设计
3. **减少错误**：提前发现逻辑问题
4. **文档基础**：成为代码文档的一部分

> **先画出草图，再写UI，最后写核心生成算法。分步调试是极客的美德。**

---

> **"好的开始是成功的一半，伪代码是编程的蓝图！"** 📐

---

<p align="center">
  <a href="#/module6/lesson19">下一课：虚实跨越（切片策略与打印支撑）→</a>
</p>

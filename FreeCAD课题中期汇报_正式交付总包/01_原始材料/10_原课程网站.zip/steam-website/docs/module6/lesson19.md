# 📍 第 19 课：虚实跨越（切片策略与打印支撑）

> **"熔融塑料若下方悬空超过45度，将因重力塌陷，必须添加辅助支撑。"**

---

## 📐 物理/数理原理

### 热熔融沉积（FDM）与重力约束

**FDM（熔融沉积成型）原理**：
1. 热塑性材料（PLA/ABS）被加热至熔融状态（约200°C）
2. 熔融材料通过喷嘴挤出
3. 材料逐层堆积并冷却固化

**重力约束**：
- 熔融材料需要下方支撑
- 悬空角度超过45°时，材料会下垂塌陷
- 悬空部分需要添加"支撑结构"

**支撑结构**：
- 临时支撑悬空部分
- 打印完成后可拆除
- 会增加打印时间和材料消耗

> 💡 **设计优化**：通过修改模型设计（如加粗壁厚、减少悬空），可以减少或避免支撑。

---

## 💻 FreeCAD 操作步骤

### 导出STL文件

```python
import FreeCAD as App

# 获取活动文档
doc = App.ActiveDocument

# 选择要导出的对象
obj = doc.getObject("MyModel")

if obj:
    # 导出为STL格式
    obj.Shape.exportStl("/path/to/output/model.stl")
    App.Console.PrintMessage("✅ STL文件导出成功！\n")
else:
    App.Console.PrintMessage("❌ 未找到指定对象\n")
```

### 手动导出步骤

1. **在 FreeCAD 中选中最终模型**
2. **点击菜单栏 `文件 (File)` → `导出 (Export)`**
3. **格式选择 `.stl`**
4. **选择保存位置并命名**

---

## 📋 实验报告

### 观察记录

将STL导入切片软件（如 Cura）后：
1. ✅ 设置层高 `0.2mm`，填充 `15%`
2. ✅ 针对 Python 生成的镂空图案开启了"生成支撑"
3. ✅ 切片软件显示了打印时间和材料用量预估

### 切片参数对比

| 参数 | 低质量 | 标准 | 高质量 |
|:---|:---:|:---:|:---:|
| 层高 | 0.3mm | 0.2mm | 0.1mm |
| 填充密度 | 10% | 15-20% | 30%+ |
| 打印速度 | 快 | 中等 | 慢 |
| 表面质量 | 一般 | 良好 | 优秀 |
| 打印时间 | 短 | 中等 | 长 |

### 思考问题

1. 如何设计模型以减少支撑？
2. 壁厚对打印强度有什么影响？
3. 不同的填充模式有什么特点？

---

## 🔧 制作指南

### 切片软件设置

**Cura 关键参数**：

| 参数 | 推荐值 | 说明 |
|:---|:---:|:---|
| 层高 | 0.2mm | 精度与速度的平衡 |
| 壁厚 | 2-3层 | 外壳强度 |
| 顶/底层厚度 | 0.8mm | 表面质量 |
| 填充密度 | 15-20% | 内部填充比例 |
| 填充图案 | 网格/三角形 | 强度与速度 |
| 打印温度 | 200°C (PLA) | 材料熔化温度 |
| 热床温度 | 60°C (PLA) | 防止翘边 |
| 支撑 | 按需开启 | 悬空部分支撑 |
| 支撑角度 | 45° | 超过此角度生成支撑 |

### 模型设计优化

```python
import FreeCAD as App
import Part
from FreeCAD import Vector

def create_printable_box(length, width, height, wall_thickness=2.0):
    """
    创建一个适合3D打印的盒子
    
    优化点：
    1. 足够的壁厚保证强度
    2. 圆角减少应力集中
    3. 底部加厚防止翘边
    """
    doc = App.ActiveDocument
    
    # 外框
    outer = Part.makeBox(length, width, height)
    
    # 内腔（挖空）
    inner_length = length - 2 * wall_thickness
    inner_width = width - 2 * wall_thickness
    inner_height = height - wall_thickness - 2  # 底部加厚2mm
    
    if inner_length > 0 and inner_width > 0 and inner_height > 0:
        inner = Part.makeBox(inner_length, inner_width, inner_height)
        inner.translate(Vector(wall_thickness, wall_thickness, 2))
        
        box = outer.cut(inner)
    else:
        box = outer
    
    return box

# 创建优化后的盒子
doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()

printable_box = create_printable_box(60, 40, 30, wall_thickness=2.5)
obj = doc.addObject("Part::Feature", "PrintableBox")
obj.Shape = printable_box
obj.ViewObject.ShapeColor = (0.3, 0.7, 0.9)

doc.recompute()
```

### 支撑设计原则

```
✅ 需要支撑的情况：
   - 悬空角度 > 45°
   - 桥接距离 > 5mm
   - 尖顶结构

❌ 避免支撑的设计：
   - 将悬空改为斜坡
   - 添加倒角或圆角
   - 分割模型分件打印
   - 调整模型摆放角度
```

---

## 🎯 课后挑战

### 挑战1：创建可打印的笔筒

```python
import FreeCAD as App
import Part
from FreeCAD import Vector

def create_printable_pen_holder():
    """
    创建一个优化3D打印的笔筒
    
    优化点：
    1. 底部加厚（3mm）
    2. 壁厚2.5mm
    3. 顶部圆角
    4. 无悬空结构
    """
    doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()
    
    # 参数
    outer_radius = 35
    height = 100
    wall_thickness = 2.5
    bottom_thickness = 3
    
    # 外层圆柱
    outer = Part.makeCylinder(outer_radius, height)
    
    # 内层挖空
    inner_radius = outer_radius - wall_thickness
    inner = Part.makeCylinder(inner_radius, height - bottom_thickness)
    inner.translate(Vector(0, 0, bottom_thickness))
    
    # 创建笔筒主体
    holder = outer.cut(inner)
    
    # 创建对象
    obj = doc.addObject("Part::Feature", "PrintablePenHolder")
    obj.Shape = holder
    obj.ViewObject.ShapeColor = (0.3, 0.6, 0.9)
    
    doc.recompute()
    
    App.Console.PrintMessage("✅ 可打印笔筒已创建\n")
    App.Console.PrintMessage(f"   外径：{outer_radius*2}mm\n")
    App.Console.PrintMessage(f"   高度：{height}mm\n")
    App.Console.PrintMessage(f"   壁厚：{wall_thickness}mm\n")
    App.Console.PrintMessage(f"   底厚：{bottom_thickness}mm\n")
    
    return obj

# 创建笔筒
pen_holder = create_printable_pen_holder()
```

### 挑战2：导出并切片

完成上述模型后：

1. **导出STL**：
   ```python
   pen_holder.Shape.exportStl("/home/user/pen_holder.stl")
   ```

2. **Cura切片设置**：
   - 层高：0.2mm
   - 壁厚：3层
   - 填充：15%
   - 支撑：关闭（此设计无需支撑）

3. **预估打印时间**：约2-3小时

---

## 📚 知识小结

### 本课重点

1. ✅ 理解了FDM打印的物理原理
2. ✅ 掌握了STL导出方法
3. ✅ 学会了切片参数设置

### 关键参数

| 参数 | 标准值 | 作用 |
|:---|:---:|:---|
| 层高 | 0.2mm | 打印精度 |
| 填充密度 | 15-20% | 内部强度 |
| 壁厚 | 2-3mm | 外壳强度 |
| 支撑角度 | 45° | 悬空判断 |

### 设计优化原则

1. **壁厚足够**：至少2mm
2. **避免大悬空**：角度<45°
3. **底部加厚**：防止翘边
4. **合理填充**：15-20%足够日常使用

> **回顾你的 Python 算法，能否通过修改代码参数（比如加粗壁厚变量 `thickness = 2.0`）来让模型在物理打印时更坚固？**

---

> **"从虚拟到现实，是造物主最激动人心的时刻！"** 🖨️

---

<p align="center">
  <a href="#/module6/lesson20">下一课：智造发布会（答辩、开源与反思）→</a>
</p>

# 📍 第 9 课：自然韵律（三角函数与波浪面模拟）

> **"正弦和余弦函数描述了自然界中的声波、水波以及电磁波的周期性变化。"**

---

## 📐 物理/数理原理

### 简谐振动

在自然界中，**声波、水波以及电磁波的传播都遵循着周期性规律**。在数学上，我们使用**正弦函数**和**余弦函数**来描述这种简谐振动。

**正弦函数公式**：
$$y = A \cdot \sin(\omega x + \phi)$$

其中：
- **$A$ (振幅)**：决定波浪的起伏高度
- **$\omega$ (角频率)**：决定波浪的密集程度（波长）
- **$\phi$ (初相位)**：决定波浪的起始位置

**波长与频率的关系**：
$$\lambda = \frac{2\pi}{\omega}$$

> 💡 **应用场景**：声学降噪板、建筑美学设计、船舶外形、音响设备等。

---

## 💻 FreeCAD 脚本

### 基础正弦曲线

```python
import FreeCAD as App
import Part
import math
from FreeCAD import Vector

doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()

# 利用三角函数计算波浪坐标
points = []
amplitude = 5.0      # 振幅：5mm
frequency = 0.5      # 频率

for i in range(100):
    x = i
    z = amplitude * math.sin(frequency * x)
    points.append(Vector(x, 0, z))

# 拟合平滑的B样条曲线
wave_curve = Part.BSplineCurve()
wave_curve.buildFromPoles(points)

# 创建边并显示
wave_edge = Part.Edge(wave_curve)
obj = doc.addObject("Part::Feature", "SineWave")
obj.Shape = wave_edge
obj.ViewObject.LineColor = (0.0, 0.5, 1.0)
obj.ViewObject.LineWidth = 3.0

doc.recompute()

App.Console.PrintMessage(f"正弦波生成完成！振幅：{amplitude}mm\n")
```

### 波浪曲面（拉伸）

```python
import Part
import math
from FreeCAD import Vector

doc = App.ActiveDocument

# 创建波浪曲面的点
points = []
amplitude = 5.0
frequency = 0.3

for i in range(100):
    x = i
    z = amplitude * math.sin(frequency * x)
    points.append(Vector(x, 0, z))

# 创建B样条曲线
wave_curve = Part.BSplineCurve()
wave_curve.buildFromPoles(points)
wave_edge = Part.Edge(wave_curve)

# 将曲线拉伸成曲面（沿Y轴方向拉伸50mm）
wave_face = Part.Face(Part.Wire([wave_edge]))
wave_solid = wave_face.extrude(Vector(0, 50, 0))

obj = doc.addObject("Part::Feature", "WaveSurface")
obj.Shape = wave_solid
obj.ViewObject.ShapeColor = (0.3, 0.7, 1.0)

doc.recompute()
```

---

## 📋 实验报告

### 观察记录

运行波浪曲面代码后：
1. ✅ 生成了一条优美的正弦波浪线
2. ✅ 波浪被拉伸成了一块宽50mm、长100mm的波浪形曲面板
3. ✅ 通过修改振幅和频率参数，可以模拟不同的波浪效果

### 参数探究

| 参数 | 值 | 效果 |
|:---|:---:|:---|
| amplitude | 5.0 | 波峰高度5mm |
| amplitude | 15.0 | 波峰明显变陡 |
| frequency | 0.5 | 波浪较密集 |
| frequency | 0.1 | 波浪更加平缓宽阔 |

### 思考问题

1. 如何创建余弦波？
2. 如何让波浪沿Y轴方向延伸？
3. 如何创建二维波浪面（X和Y方向都有波浪）？

---

## 🔧 制作指南

### 二维波浪面

```python
import Part
import math
from FreeCAD import Vector

doc = App.ActiveDocument

# 创建二维波浪面的点网格
points_2d = []
rows = 50
cols = 50

for row in range(rows):
    row_points = []
    for col in range(cols):
        x = col
        y = row
        # 二维正弦波
        z = 5 * math.sin(0.2 * x) + 3 * math.cos(0.15 * y)
        row_points.append(Vector(x, y, z))
    points_2d.append(row_points)

# 创建曲面（简化版：使用点云生成）
# 注意：完整实现需要更复杂的曲面生成代码
# 这里展示概念

App.Console.PrintMessage(f"创建了 {rows}x{cols} 的波浪点网格\n")
```

### 双波浪叠加

```python
import Part
import math
from FreeCAD import Vector

doc = App.ActiveDocument

# 两个不同频率的波浪叠加
points = []

for i in range(150):
    x = i * 0.5
    # 波浪1：低频大振幅
    wave1 = 8 * math.sin(0.3 * x)
    # 波浪2：高频小振幅
    wave2 = 3 * math.sin(0.8 * x)
    # 叠加
    z = wave1 + wave2
    points.append(Vector(x, 0, z))

# 创建曲线
wave_curve = Part.BSplineCurve()
wave_curve.buildFromPoles(points)
wave_edge = Part.Edge(wave_curve)

obj = doc.addObject("Part::Feature", "DoubleWave")
obj.Shape = wave_edge
obj.ViewObject.LineColor = (0.8, 0.3, 0.8)
obj.ViewObject.LineWidth = 3.0

doc.recompute()
```

### 螺旋线（使用三角函数）

```python
import Part
import math
from FreeCAD import Vector

doc = App.ActiveDocument

# 创建螺旋线
points = []
turns = 3
points_per_turn = 50
radius = 20
pitch = 10  # 每圈上升高度

total_points = turns * points_per_turn

for i in range(total_points):
    angle = 2 * math.pi * i / points_per_turn
    t = i / total_points
    
    x = radius * math.cos(angle)
    y = radius * math.sin(angle)
    z = t * turns * pitch
    
    points.append(Vector(x, y, z))

# 创建螺旋线
helix_curve = Part.BSplineCurve()
helix_curve.buildFromPoles(points)
helix_edge = Part.Edge(helix_curve)

obj = doc.addObject("Part::Feature", "Helix")
obj.Shape = helix_edge
obj.ViewObject.LineColor = (1.0, 0.5, 0.2)
obj.ViewObject.LineWidth = 4.0

doc.recompute()
```

---

## 🎯 课后挑战

### 挑战1：创建莫比乌斯环

```python
import Part
import math
from FreeCAD import Vector

doc = App.ActiveDocument

# 创建莫比乌斯环的点
points = []
major_radius = 30   # 主半径
minor_radius = 10   # 截面半径
segments = 100

for i in range(segments + 1):
    t = 2 * math.pi * i / segments
    
    # 莫比乌斯环参数方程
    x = (major_radius + minor_radius * math.cos(t/2)) * math.cos(t)
    y = (major_radius + minor_radius * math.cos(t/2)) * math.sin(t)
    z = minor_radius * math.sin(t/2)
    
    points.append(Vector(x, y, z))

# 创建曲线
mobius_curve = Part.BSplineCurve()
mobius_curve.buildFromPoles(points)
mobius_edge = Part.Edge(mobius_curve)

obj = doc.addObject("Part::Feature", "MobiusStrip")
obj.Shape = mobius_edge
obj.ViewObject.LineColor = (0.2, 0.8, 0.4)
obj.ViewObject.LineWidth = 4.0

doc.recompute()
```

### 挑战2：创建声学降噪墙板

```python
import Part
import math
from FreeCAD import Vector

doc = App.ActiveDocument

# 创建声学降噪墙板
panel_width = 200
panel_length = 100
wave_height = 8
wave_freq_x = 0.2
wave_freq_y = 0.15

# 创建基础矩形
base_points = [
    Vector(0, 0, 0),
    Vector(panel_width, 0, 0),
    Vector(panel_width, panel_length, 0),
    Vector(0, panel_length, 0),
    Vector(0, 0, 0)
]

# 创建波浪边缘
wave_points = []
num_points = 100

for i in range(num_points):
    # 沿边缘移动
    t = i / num_points
    if t < 0.25:  # 底边
        x = t * 4 * panel_width
        y = 0
    elif t < 0.5:  # 右边
        x = panel_width
        y = (t - 0.25) * 4 * panel_length
    elif t < 0.75:  # 顶边
        x = panel_width - (t - 0.5) * 4 * panel_width
        y = panel_length
    else:  # 左边
        x = 0
        y = panel_length - (t - 0.75) * 4 * panel_length
    
    # 添加波浪高度
    z = wave_height * math.sin(wave_freq_x * x) * math.cos(wave_freq_y * y)
    wave_points.append(Vector(x, y, z))

# 创建闭合多段线
wave_points.append(wave_points[0])
wave_wire = Part.makePolygon(wave_points)

obj = doc.addObject("Part::Feature", "AcousticPanel")
obj.Shape = wave_wire
obj.ViewObject.LineColor = (0.4, 0.6, 0.8)
obj.ViewObject.LineWidth = 3.0

doc.recompute()
```

---

## 📚 知识小结

### 本课重点

1. ✅ 理解了三角函数在描述周期性现象中的作用
2. ✅ 掌握了使用正弦/余弦函数创建波浪曲线
3. ✅ 学会了将曲线拉伸成曲面

### 关键API

| 函数 | 说明 |
|:---|:---|
| `math.sin(x)` | 正弦函数（x为弧度） |
| `math.cos(x)` | 余弦函数（x为弧度） |
| `math.radians(deg)` | 角度转弧度 |
| `math.degrees(rad)` | 弧度转角度 |
| `Part.BSplineCurve()` | 创建B样条曲线 |
| `face.extrude(vector)` | 拉伸成实体 |

### 三角函数图像

```
sin(x):  在x=0时为0，x=π/2时为1，x=π时为0，x=3π/2时为-1
cos(x):  在x=0时为1，x=π/2时为0，x=π时为-1，x=3π/2时为0
```

> **如果将波浪线沿 Y 轴拉伸（Extrude），就能得到一块声学降噪墙板。**

---

> **"三角函数是自然的语言，让我们用代码翻译它！"** 🌊

---

<p align="center">
  <a href="#/module3/lesson10">下一课：分形与迭代（算法生成艺术）→</a>
</p>

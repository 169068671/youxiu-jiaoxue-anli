# 📍 第 7 课：数据的容器（List 列表与多段线）

> **"复杂的曲面或航线往往由一组储存在列表中的离散坐标点拟合而成。"**

---

## 📐 物理/数理原理

### 离散点集与样条曲线

在工程和科学中，**复杂的曲线或曲面通常由一组离散的数据点来描述**。

**离散点集**：一系列有序的坐标点
$$P = \{(x_1, y_1, z_1), (x_2, y_2, z_2), ..., (x_n, y_n, z_n)\}$$

**样条曲线（Spline）**：通过离散点集拟合出的平滑曲线
- 多段线（Polygon）：点与点之间用直线连接
- B样条曲线（B-Spline）：平滑的曲线拟合

> 💡 **应用场景**：3D扫描的点云数据、无人机航线规划、汽车外形设计等。

---

## 💻 FreeCAD 脚本

### 基础列表操作

```python
import FreeCAD as App
import Part
from FreeCAD import Vector

doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()

# 定义空间中的关键点列表
points = [
    Vector(0, 0, 0),
    Vector(10, 20, 0),
    Vector(20, 0, 10),
    Vector(30, 20, 0),
    Vector(40, 0, 0)
]

# 用多段线将点连接起来
polygon = Part.makePolygon(points)

# 显示多段线
obj = doc.addObject("Part::Feature", "MyPolygon")
obj.Shape = polygon
obj.ViewObject.LineColor = (0.0, 0.5, 1.0)
obj.ViewObject.LineWidth = 3.0

doc.recompute()

App.Console.PrintMessage(f"创建了包含 {len(points)} 个点的多段线\n")
```

### 列表的基本操作

```python
# 创建列表
my_list = [10, 20, 30, 40, 50]

# 访问元素（索引从0开始）
first = my_list[0]    # 10
second = my_list[1]   # 20
last = my_list[-1]    # 50（最后一个）

# 修改元素
my_list[0] = 100      # [100, 20, 30, 40, 50]

# 添加元素
my_list.append(60)    # [100, 20, 30, 40, 50, 60]

# 获取长度
length = len(my_list)  # 6

# 遍历列表
for item in my_list:
    print(item)

# 带索引遍历
for i, item in enumerate(my_list):
    print(f"索引 {i}: {item}")
```

---

## 📋 实验报告

### 观察记录

运行多段线代码后：
1. ✅ 空间中出现了一条折线
2. ✅ 折线精准地穿过了我们预设的每一个坐标点
3. ✅ 折线呈现蓝色，线宽为3像素

### 列表内容分析

| 索引 | 坐标点 | 说明 |
|:---:|:---|:---|
| 0 | (0, 0, 0) | 起点 - 原点 |
| 1 | (10, 20, 0) | 向右前方 |
| 2 | (20, 0, 10) | 向右上方 |
| 3 | (30, 20, 0) | 向右前方 |
| 4 | (40, 0, 0) | 终点 - 回到Z=0平面 |

### 思考问题

1. 如何在列表中添加更多点？
2. 如何创建闭合的多段线（首尾相连）？
3. 如何用循环生成大量点？

---

## 🔧 制作指南

### 用循环生成点列表

```python
import Part
from FreeCAD import Vector
import math

doc = App.ActiveDocument

# 用循环生成正弦波形的点
points = []
for i in range(50):
    x = i * 2  # X方向每步2mm
    y = 0
    z = 10 * math.sin(i * 0.3)  # Z方向正弦波动
    points.append(Vector(x, y, z))

# 创建多段线
wave_line = Part.makePolygon(points)
obj = doc.addObject("Part::Feature", "WaveLine")
obj.Shape = wave_line
obj.ViewObject.LineColor = (1.0, 0.2, 0.5)

doc.recompute()
```

### 创建闭合多段线

```python
import Part
from FreeCAD import Vector

doc = App.ActiveDocument

# 定义三角形的三个顶点
points = [
    Vector(0, 0, 0),
    Vector(50, 0, 0),
    Vector(25, 43.3, 0),  # 等边三角形的高
]

# 添加第一个点到最后，形成闭合
points.append(points[0])

# 创建闭合多段线
triangle = Part.makePolygon(points)
obj = doc.addObject("Part::Feature", "Triangle")
obj.Shape = triangle
obj.ViewObject.LineColor = (0.0, 0.8, 0.2)

doc.recompute()
```

### 列表切片操作

```python
# 创建数字列表
numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# 切片操作
first_three = numbers[0:3]      # [0, 1, 2]
last_three = numbers[-3:]       # [7, 8, 9]
middle = numbers[3:7]           # [3, 4, 5, 6]
every_second = numbers[::2]     # [0, 2, 4, 6, 8]
reversed_list = numbers[::-1]   # [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]

# 应用到3D建模
import Part
from FreeCAD import Vector

doc = App.ActiveDocument

# 创建一系列点
all_points = [Vector(i*10, 0, i*5) for i in range(10)]

# 只取前5个点创建多段线
partial_points = all_points[:5]
line = Part.makePolygon(partial_points)
obj = doc.addObject("Part::Feature", "PartialLine")
obj.Shape = line
obj.ViewObject.LineColor = (1.0, 0.5, 0.0)

doc.recompute()
```

---

## 🎯 课后挑战

### 挑战1：创建星形图案

```python
import Part
from FreeCAD import Vector
import math

doc = App.ActiveDocument

# 创建五角星的顶点
points = []
outer_radius = 50
inner_radius = 20
num_points = 5

for i in range(num_points * 2):
    angle = math.pi * i / num_points - math.pi / 2
    if i % 2 == 0:
        # 外顶点
        r = outer_radius
    else:
        # 内顶点
        r = inner_radius
    
    x = r * math.cos(angle)
    y = r * math.sin(angle)
    points.append(Vector(x, y, 0))

# 闭合星形
points.append(points[0])

# 创建星形多段线
star = Part.makePolygon(points)
obj = doc.addObject("Part::Feature", "Star")
obj.Shape = star
obj.ViewObject.LineColor = (1.0, 0.8, 0.0)
obj.ViewObject.LineWidth = 4.0

doc.recompute()
```

### 挑战2：创建螺旋线

```python
import Part
from FreeCAD import Vector
import math

doc = App.ActiveDocument

# 创建螺旋线的点
points = []
turns = 3           # 圈数
points_per_turn = 20
radius = 30
height_per_turn = 20

total_points = turns * points_per_turn

for i in range(total_points):
    angle = 2 * math.pi * i / points_per_turn
    t = i / total_points  # 0到1的进度
    
    x = radius * math.cos(angle)
    y = radius * math.sin(angle)
    z = t * turns * height_per_turn
    
    points.append(Vector(x, y, z))

# 创建螺旋线
helix = Part.makePolygon(points)
obj = doc.addObject("Part::Feature", "Helix")
obj.Shape = helix
obj.ViewObject.LineColor = (0.5, 0.2, 1.0)
obj.ViewObject.LineWidth = 3.0

doc.recompute()
```

---

## 📚 知识小结

### 本课重点

1. ✅ 理解了列表的概念和用途
2. ✅ 掌握了列表的创建、访问和修改
3. ✅ 学会了用列表存储点坐标并创建多段线

### 关键语法

| 语法 | 说明 |
|:---|:---|
| `[a, b, c]` | 创建列表 |
| `list[i]` | 访问第i个元素（从0开始） |
| `list.append(x)` | 在末尾添加元素 |
| `len(list)` | 获取列表长度 |
| `list[start:end]` | 切片操作 |
| `for item in list` | 遍历列表 |

### 列表与3D建模

```python
# 列表存储点坐标
points = [Vector(x1,y1,z1), Vector(x2,y2,z2), ...]

# 创建多段线
polygon = Part.makePolygon(points)
```

> **列表是我们管理海量数据（如 3D 扫描的点云数据）的基础。**

---

> **"列表是数据的容器，让复杂的信息变得井井有条！"** 📦

---

<p align="center">
  <a href="#/module3/lesson08">下一课：封装造物术（def 函数与模块化设计）→</a>
</p>

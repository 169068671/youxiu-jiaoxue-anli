# 📍 第 10 课：分形与迭代（算法生成艺术）

> **"局部与整体具有自相似性，用极简规则生成无限复杂的形态。"**

---

## 📐 物理/数理原理

### 分形几何（Fractal）

**分形**是一种具有**自相似性**的几何图形：
- 局部与整体具有相似的形状
- 通过简单的规则递归或迭代生成
- 可以产生无限复杂的形态

**著名分形图形**：
- **谢尔宾斯基三角形**：不断挖去中心三角形
- **科赫雪花**：每条边不断添加凸起
- **曼德勃罗集**：复数平面的迭代

**分形的维度**：
- 普通几何：点（0维）、线（1维）、面（2维）、体（3维）
- 分形：维度可以是分数（如1.26维）

> 💡 **自然中的分形**：海岸线、云朵、山脉、树枝、血管网络等。

---

## 💻 FreeCAD 脚本

### 基础迭代：谢尔宾斯基地毯雏形

```python
import FreeCAD as App
import Part
from FreeCAD import Vector

doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()

# 基础迭代思想：嵌套循环生成网格阵列
box_size = 8
gap = 2

for x in range(0, 30, 10):
    for y in range(0, 30, 10):
        # 留出中间的空洞，形成类似谢尔宾斯基地毯的雏形
        if x != 10 or y != 10:
            box = Part.makeBox(box_size, box_size, box_size)
            obj = doc.addObject("Part::Feature", f"Box_{x}_{y}")
            obj.Shape = box
            obj.Placement.Base = Vector(x, y, 0)
            
            # 根据位置设置颜色
            intensity = (x + y) / 60.0
            obj.ViewObject.ShapeColor = (intensity, 0.5, 1.0 - intensity)

doc.recompute()

App.Console.PrintMessage("谢尔宾斯基地毯雏形生成完成！\n")
```

### 递归分形树

```python
import Part
from FreeCAD import Vector
import math

doc = App.ActiveDocument

def create_branch(start, angle, length, depth):
    """
    递归创建分形树枝
    
    参数:
        start: 起始点
        angle: 角度（弧度）
        length: 长度
        depth: 递归深度
    """
    if depth <= 0:
        return []
    
    # 计算终点
    end = Vector(
        start.x + length * math.cos(angle),
        start.y + length * math.sin(angle),
        start.z
    )
    
    # 创建当前分支
    branch = Part.makeLine(start, end)
    
    # 递归创建子分支
    branches = [branch]
    
    # 左分支
    branches.extend(create_branch(
        end, 
        angle + math.pi/6,  # 向左偏转30度
        length * 0.7,       # 长度缩短
        depth - 1
    ))
    
    # 右分支
    branches.extend(create_branch(
        end,
        angle - math.pi/6,  # 向右偏转30度
        length * 0.7,
        depth - 1
    ))
    
    return branches

# 创建分形树（简化版：只生成主干）
start_point = Vector(0, 0, 0)
initial_angle = math.pi / 2  # 向上
initial_length = 30
max_depth = 4

# 由于递归生成复杂几何体可能导致性能问题
# 这里展示简化版本：手动创建几层分支

# 主干
trunk = Part.makeCylinder(3, 40)
trunk_obj = doc.addObject("Part::Feature", "Trunk")
trunk_obj.Shape = trunk
trunk_obj.ViewObject.ShapeColor = (0.4, 0.25, 0.1)  # 棕色

# 第一层分支
for i in range(3):
    angle = math.pi/2 + (i - 1) * math.pi/4
    branch = Part.makeCylinder(2, 20)
    branch_obj = doc.addObject("Part::Feature", f"Branch1_{i}")
    branch_obj.Shape = branch
    branch_obj.Placement.Base = Vector(0, 0, 35)
    branch_obj.Placement.Rotation.Axis = Vector(0, 0, 1)
    branch_obj.Placement.Rotation.Angle = angle - math.pi/2
    branch_obj.ViewObject.ShapeColor = (0.4, 0.25, 0.1)

doc.recompute()
```

---

## 📋 实验报告

### 观察记录

运行谢尔宾斯基地毯代码后：
1. ✅ 生成了一个 3x3 的方块阵列
2. ✅ 中心位置 (10, 10) 被精确地留空了
3. ✅ 这是分形几何中"自相似"概念的雏形

### 迭代过程分析

| 迭代次数 | 方块数量 | 剩余比例 |
|:---:|:---:|:---:|
| 0 | 1 | 100% |
| 1 | 8 | 88.9% |
| 2 | 64 | 79.0% |
| 3 | 512 | 70.1% |

### 思考问题

1. 如何实现真正的递归谢尔宾斯基三角形？
2. 分形图案在3D打印中有什么应用？
3. 如何控制递归深度以避免电脑卡死？

---

## 🔧 制作指南

### 安全迭代原则

```python
# 设置最大递归深度，防止电脑卡死
MAX_DEPTH = 5

def safe_fractal(depth):
    if depth > MAX_DEPTH:
        print("已达到最大递归深度，停止迭代")
        return
    
    # 执行当前层级的操作
    # ...
    
    # 递归调用
    safe_fractal(depth + 1)

# 从第0层开始
safe_fractal(0)
```

### 迭代vs递归

```python
# 迭代方式（推荐，性能更好）
def create_grid_iterative(size, levels):
    """使用迭代创建网格"""
    for level in range(levels):
        step = size / (3 ** level)
        for x in range(0, size, int(step)):
            for y in range(0, size, int(step)):
                # 创建方块
                pass

# 递归方式（代码简洁，但可能卡死）
def create_grid_recursive(x, y, size, depth):
    """使用递归创建网格"""
    if depth <= 0:
        return
    
    # 创建当前方块
    # ...
    
    # 递归创建子方块
    new_size = size / 3
    for dx in [0, 1, 2]:
        for dy in [0, 1, 2]:
            if dx != 1 or dy != 1:  # 跳过中心
                create_grid_recursive(
                    x + dx * new_size,
                    y + dy * new_size,
                    new_size,
                    depth - 1
                )
```

### 科赫雪花（简化版）

```python
import Part
from FreeCAD import Vector
import math

doc = App.ActiveDocument

def koch_line(start, end, depth):
    """
    创建科赫曲线的一段
    
    参数:
        start: 起点
        end: 终点
        depth: 递归深度
    """
    if depth <= 0:
        return Part.makeLine(start, end)
    
    # 计算三分点
    p1 = start + (end - start) * (1/3)
    p2 = start + (end - start) * (2/3)
    
    # 计算凸起点（等边三角形的顶点）
    # 简化：直接返回线段
    return Part.makeLine(start, end)

# 创建三角形的三条边
size = 50
height = size * math.sqrt(3) / 2

p1 = Vector(0, 0, 0)
p2 = Vector(size, 0, 0)
p3 = Vector(size/2, height, 0)

# 创建三角形
edge1 = Part.makeLine(p1, p2)
edge2 = Part.makeLine(p2, p3)
edge3 = Part.makeLine(p3, p1)

wire = Part.Wire([edge1, edge2, edge3])
obj = doc.addObject("Part::Feature", "KochBase")
obj.Shape = wire
obj.ViewObject.LineColor = (0.2, 0.6, 1.0)
obj.ViewObject.LineWidth = 3.0

doc.recompute()
```

---

## 🎯 课后挑战

### 挑战1：创建门格海绵雏形

```python
import Part
from FreeCAD import Vector

doc = App.ActiveDocument

# 门格海绵：3x3x3立方体，移除中心及面中心的7个小立方体
def create_menger_sponge(size, position, level):
    """创建门格海绵"""
    if level <= 0:
        box = Part.makeBox(size, size, size)
        obj = doc.addObject("Part::Feature", f"Menger_{position.x}_{position.y}")
        obj.Shape = box
        obj.Placement.Base = position
        return
    
    new_size = size / 3
    
    for x in range(3):
        for y in range(3):
            for z in range(3):
                # 跳过中心及面中心的立方体
                if (x == 1 and y == 1) or (x == 1 and z == 1) or (y == 1 and z == 1):
                    continue
                
                new_pos = Vector(
                    position.x + x * new_size,
                    position.y + y * new_size,
                    position.z + z * new_size
                )
                
                # 递归创建（简化：只创建一层）
                box = Part.makeBox(new_size*0.9, new_size*0.9, new_size*0.9)
                obj = doc.addObject("Part::Feature", f"Box_{x}_{y}_{z}")
                obj.Shape = box
                obj.Placement.Base = new_pos
                obj.ViewObject.ShapeColor = (
                    x/3, y/3, z/3
                )

# 创建门格海绵（第一层）
create_menger_sponge(30, Vector(0, 0, 0), 1)

doc.recompute()
```

### 挑战2：创建随机地形

```python
import Part
from FreeCAD import Vector
import random

doc = App.ActiveDocument

# 设置随机种子（保证可重复）
random.seed(42)

# 创建随机地形
size = 10
box_size = 5

for x in range(size):
    for y in range(size):
        # 随机高度
        height = random.uniform(2, 20)
        
        # 创建柱子
        box = Part.makeBox(box_size*0.9, box_size*0.9, height)
        obj = doc.addObject("Part::Feature", f"Terrain_{x}_{y}")
        obj.Shape = box
        obj.Placement.Base = Vector(x*box_size, y*box_size, 0)
        
        # 根据高度设置颜色
        intensity = height / 20.0
        obj.ViewObject.ShapeColor = (
            0.2 + intensity * 0.3,  # 绿色
            0.5 + intensity * 0.4,
            0.2
        )

doc.recompute()
```

---

## 📚 知识小结

### 本课重点

1. ✅ 理解了分形几何的自相似性概念
2. ✅ 掌握了迭代和递归的基本思想
3. ✅ 学会了创建简单的分形图案

### 关键概念

| 概念 | 说明 |
|:---|:---|
| 自相似性 | 局部与整体形状相似 |
| 迭代 | 重复执行同一操作 |
| 递归 | 函数调用自身 |
| 分形维度 | 可以是分数维度 |

### 安全提示

> ⚠️ **递归非常消耗电脑内存，测试时参数不要给得太大，以防 FreeCAD 卡死！**

建议：
- 设置最大递归深度
- 使用迭代代替递归（性能更好）
- 先测试小参数，确认无误再增大

---

> **"分形是大自然的密码，迭代是解开它的钥匙！"** 🔑

---

<p align="center">
  <a href="#/module4/lesson11">下一课：告别黑框（PySide 基础与按钮）→</a>
</p>

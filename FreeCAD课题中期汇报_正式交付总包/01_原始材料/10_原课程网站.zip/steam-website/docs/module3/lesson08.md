# 📍 第 8 课：封装造物术（def 函数与模块化设计）

> **"将复杂的机械结构封装成一个具有输入参数的黑盒，提高复用率。"**

---

## 📐 物理/数理原理

### 系统工程中的"模块化封装"思想

在工程设计中，**模块化**是一种重要的设计思想：
- 将复杂系统分解为独立的模块
- 每个模块有明确的输入和输出
- 模块之间通过接口进行交互

**函数的本质**：
- 一个可重复使用的代码块
- 接收输入参数（原料）
- 返回输出结果（产品）
- 内部实现被"封装"起来

> 💡 **实际应用**：汽车由发动机、底盘、车身等模块组成；每个模块可以独立设计、测试和更换。

---

## 💻 FreeCAD 脚本

### 基础函数定义

```python
import FreeCAD as App
import Part

doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()

# 定义一个制造带孔方块的"车床"函数
def make_hollow_box(size, hole_radius):
    """
    创建一个带中心孔的方块
    
    参数:
        size: 方块边长
        hole_radius: 孔的半径
    """
    # 外方块
    outer = Part.makeBox(size, size, size)
    
    # 内圆柱（孔）
    inner = Part.makeCylinder(hole_radius, size)
    inner.translate(App.Vector(size/2, size/2, 0))
    
    # 布尔运算：减去中间的圆柱
    result = outer.cut(inner)
    
    return result

# 呼叫我们的车床，立刻生产两个不同规格的零件
box1 = make_hollow_box(20, 5)
obj1 = doc.addObject("Part::Feature", "HollowBox_20_5")
obj1.Shape = box1
obj1.Placement.Base = App.Vector(0, 0, 0)
obj1.ViewObject.ShapeColor = (0.3, 0.6, 1.0)

box2 = make_hollow_box(30, 8)
obj2 = doc.addObject("Part::Feature", "HollowBox_30_8")
obj2.Shape = box2
obj2.Placement.Base = App.Vector(40, 0, 0)
obj2.ViewObject.ShapeColor = (1.0, 0.5, 0.3)

doc.recompute()

App.Console.PrintMessage("带孔方块生成完成！\n")
```

### 函数的结构

```python
def 函数名(参数1, 参数2, ...):
    """
    函数的文档说明（docstring）
    说明函数的功能、参数和返回值
    """
    # 函数体：执行具体的操作
    结果 = 某些操作
    
    return 结果  # 返回结果
```

---

## 📋 实验报告

### 观察记录

运行函数代码后：
1. ✅ 利用自定义函数，一行代码就能完成"画方块-画圆柱-切除"的复杂流程
2. ✅ 成功生成了两个不同规格的带孔方块
3. ✅ 函数可以被多次调用，每次使用不同的参数

### 函数调用分析

| 调用 | size | hole_radius | 结果 |
|:---|:---:|:---:|:---|
| `make_hollow_box(20, 5)` | 20 | 5 | 20mm方块，5mm孔径 |
| `make_hollow_box(30, 8)` | 30 | 8 | 30mm方块，8mm孔径 |

### 思考问题

1. 如果要生成10个不同尺寸的带孔方块，需要写多少行代码？
2. 如何修改函数，让孔的位置可以自定义？
3. 函数可以返回多个值吗？

---

## 🔧 制作指南

### 带默认参数的函数

```python
import Part

def make_cylinder_with_defaults(radius=10, height=20, color=(0.5, 0.5, 0.5)):
    """
    创建圆柱体，带有默认参数
    
    参数:
        radius: 半径（默认10）
        height: 高度（默认20）
        color: 颜色（默认灰色）
    """
    cylinder = Part.makeCylinder(radius, height)
    return cylinder

# 使用默认参数
cyl1 = make_cylinder_with_defaults()

# 只修改部分参数
cyl2 = make_cylinder_with_defaults(radius=15)
cyl3 = make_cylinder_with_defaults(height=50)

# 修改所有参数
cyl4 = make_cylinder_with_defaults(radius=20, height=30, color=(1.0, 0.0, 0.0))
```

### 返回多个值的函数

```python
def create_box_set(width, height, depth, gap):
    """
    创建一组三个不同尺寸的盒子
    
    返回:
        (small_box, medium_box, large_box)
    """
    small = Part.makeBox(width, height, depth)
    medium = Part.makeBox(width*2, height*2, depth*2)
    large = Part.makeBox(width*3, height*3, depth*3)
    
    return small, medium, large

# 调用函数并接收多个返回值
s, m, l = create_box_set(10, 10, 10, 5)

# 在FreeCAD中显示
doc = App.ActiveDocument
obj_s = doc.addObject("Part::Feature", "SmallBox")
obj_s.Shape = s
obj_s.Placement.Base = App.Vector(0, 0, 0)

obj_m = doc.addObject("Part::Feature", "MediumBox")
obj_m.Shape = m
obj_m.Placement.Base = App.Vector(50, 0, 0)

obj_l = doc.addObject("Part::Feature", "LargeBox")
obj_l.Shape = l
obj_l.Placement.Base = App.Vector(120, 0, 0)

doc.recompute()
```

### 递归函数（进阶）

```python
import Part
from FreeCAD import Vector

def create_nested_boxes(size, depth):
    """
    递归创建嵌套的盒子
    
    参数:
        size: 当前盒子尺寸
        depth: 嵌套深度
    """
    if depth <= 0:
        return None
    
    # 创建当前盒子
    box = Part.makeBox(size, size, size)
    
    # 递归创建内部盒子
    inner = create_nested_boxes(size * 0.7, depth - 1)
    
    return box

# 创建3层嵌套盒子
doc = App.ActiveDocument
for i in range(3):
    size = 30 * (0.7 ** i)
    box = Part.makeBox(size, size, size)
    obj = doc.addObject("Part::Feature", f"NestedBox_{i}")
    obj.Shape = box
    obj.Placement.Base = Vector((30-size)/2, (30-size)/2, (30-size)/2)
    obj.ViewObject.ShapeColor = (0.3 + i*0.2, 0.5, 0.8 - i*0.2)

doc.recompute()
```

---

## 🎯 课后挑战

### 挑战1：创建参数化齿轮函数

```python
import Part
from FreeCAD import Vector
import math

def make_gear(radius, teeth, height, hole_radius):
    """
    创建一个简单的齿轮模型
    
    参数:
        radius: 齿轮半径
        teeth: 齿数
        height: 齿轮厚度
        hole_radius: 中心孔半径
    """
    doc = App.ActiveDocument
    
    # 创建齿轮主体（圆柱）
    gear_body = Part.makeCylinder(radius, height)
    gear_body.translate(Vector(0, 0, 0))
    
    # 创建中心孔
    hole = Part.makeCylinder(hole_radius, height)
    
    # 减去中心孔
    gear = gear_body.cut(hole)
    
    return gear

# 创建两个不同规格的齿轮
doc = App.ActiveDocument

gear1 = make_gear(radius=30, teeth=12, height=10, hole_radius=5)
obj1 = doc.addObject("Part::Feature", "Gear_12Teeth")
obj1.Shape = gear1
obj1.Placement.Base = Vector(0, 0, 0)
obj1.ViewObject.ShapeColor = (0.8, 0.8, 0.2)

gear2 = make_gear(radius=20, teeth=8, height=10, hole_radius=4)
obj2 = doc.addObject("Part::Feature", "Gear_8Teeth")
obj2.Shape = gear2
obj2.Placement.Base = Vector(70, 0, 0)
obj2.ViewObject.ShapeColor = (0.2, 0.8, 0.8)

doc.recompute()
```

### 挑战2：创建乐高积木函数

```python
import Part
from FreeCAD import Vector

def make_legobrick(width_units, length_units, height_units=1):
    """
    创建乐高风格的积木
    
    参数:
        width_units: 宽度（单位：乐高单位）
        length_units: 长度（单位：乐高单位）
        height_units: 高度（单位：乐高单位）
    """
    # 乐高单位尺寸
    UNIT = 8.0  # mm
    HEIGHT_UNIT = 9.6  # mm
    STUD_RADIUS = 2.4  # mm
    STUD_HEIGHT = 1.8  # mm
    
    # 计算实际尺寸
    width = width_units * UNIT
    length = length_units * UNIT
    height = height_units * HEIGHT_UNIT
    
    # 创建主体
    body = Part.makeBox(width, length, height)
    
    # 添加凸点（studs）
    for x in range(width_units):
        for y in range(length_units):
            stud = Part.makeCylinder(STUD_RADIUS, STUD_HEIGHT)
            stud_x = x * UNIT + UNIT/2
            stud_y = y * UNIT + UNIT/2
            stud.translate(Vector(stud_x, stud_y, height))
            body = body.fuse(stud)
    
    return body

# 创建乐高积木
doc = App.ActiveDocument

brick1 = make_legobrick(2, 4)
obj1 = doc.addObject("Part::Feature", "Lego_2x4")
obj1.Shape = brick1
obj1.Placement.Base = Vector(0, 0, 0)
obj1.ViewObject.ShapeColor = (1.0, 0.2, 0.2)  # 红色

brick2 = make_legobrick(2, 2, 2)
obj2 = doc.addObject("Part::Feature", "Lego_2x2x2")
obj2.Shape = brick2
obj2.Placement.Base = Vector(40, 0, 0)
obj2.ViewObject.ShapeColor = (0.2, 0.4, 1.0)  # 蓝色

doc.recompute()
```

---

## 📚 知识小结

### 本课重点

1. ✅ 理解了函数的概念和作用
2. ✅ 掌握了函数的定义和调用方法
3. ✅ 学会了使用函数进行模块化设计

### 关键语法

| 语法 | 说明 |
|:---|:---|
| `def 函数名(参数):` | 定义函数 |
| `return 值` | 返回结果 |
| `函数名(参数值)` | 调用函数 |
| `参数=默认值` | 设置默认参数 |

### 函数设计原则

1. **单一职责**：一个函数只做一件事
2. **参数清晰**：参数名要有意义
3. **文档完整**：写清楚函数的功能和参数
4. **可复用性**：设计通用的函数

> **在设计复杂产品（如汽车）时，每一个螺丝钉都可以写成一个函数。**

---

> **"函数是代码的积木，让复杂变得简单！"** 🧱

---

<p align="center">
  <a href="#/module3/lesson09">下一课：自然韵律（三角函数与波浪面模拟）→</a>
</p>

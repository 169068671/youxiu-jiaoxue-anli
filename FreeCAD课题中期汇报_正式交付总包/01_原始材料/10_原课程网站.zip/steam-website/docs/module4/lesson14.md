# 📍 第 14 课：我的定制工坊（GUI网格布局设计）

> **"利用UI框架中的矩阵坐标，科学合理地排布控件，符合人机工程学。"**

---

## 📐 物理/数理原理

### 网格拓扑布局

**网格布局（Grid Layout）**是一种二维布局系统：
- 将界面划分为行（Row）和列（Column）
- 每个控件占据一个或多个单元格
- 类似于电子表格的结构

**布局原则**：
1. **对齐**：相关控件左对齐或右对齐
2. **分组**：功能相关的控件放在一起
3. **层次**：重要的信息放在显眼位置
4. **留白**：控件之间保持适当间距

> 💡 **人机工程学**：良好的界面布局可以减少用户的认知负担，提高操作效率。

---

## 💻 FreeCAD 脚本

### 基础网格布局

```python
from PySide import QtGui
import FreeCAD as App
import Part

class GridUI(QtGui.QWidget):
    """网格布局示例"""
    
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        self.setWindowTitle("参数化控制台")
        self.setGeometry(300, 300, 400, 250)
        
        # 创建网格布局
        layout = QtGui.QGridLayout()
        
        # 第0行：长度
        layout.addWidget(QtGui.QLabel("长度:"), 0, 0)      # 第0行，第0列
        self.length_input = QtGui.QLineEdit("100")
        layout.addWidget(self.length_input, 0, 1)          # 第0行，第1列
        layout.addWidget(QtGui.QLabel("mm"), 0, 2)         # 第0行，第2列
        
        # 第1行：宽度
        layout.addWidget(QtGui.QLabel("宽度:"), 1, 0)      # 第1行，第0列
        self.width_input = QtGui.QLineEdit("50")
        layout.addWidget(self.width_input, 1, 1)           # 第1行，第1列
        layout.addWidget(QtGui.QLabel("mm"), 1, 2)         # 第1行，第2列
        
        # 第2行：高度
        layout.addWidget(QtGui.QLabel("高度:"), 2, 0)      # 第2行，第0列
        self.height_input = QtGui.QLineEdit("30")
        layout.addWidget(self.height_input, 2, 1)          # 第2行，第1列
        layout.addWidget(QtGui.QLabel("mm"), 2, 2)         # 第2行，第2列
        
        # 第3行：生成按钮（跨两列）
        self.generate_btn = QtGui.QPushButton("生成模型")
        self.generate_btn.clicked.connect(self.generate)
        layout.addWidget(self.generate_btn, 3, 0, 1, 2)    # 第3行，第0列，占1行2列
        
        # 第4行：状态标签
        self.status_label = QtGui.QLabel("就绪")
        self.status_label.setStyleSheet("color: #666;")
        layout.addWidget(self.status_label, 4, 0, 1, 3)    # 第4行，第0列，占1行3列
        
        self.setLayout(layout)
        self.show()
    
    def generate(self):
        try:
            l = float(self.length_input.text())
            w = float(self.width_input.text())
            h = float(self.height_input.text())
            
            box = Part.makeBox(l, w, h)
            Part.show(box)
            
            self.status_label.setText(f"✅ 已生成：{l} x {w} x {h} mm")
            self.status_label.setStyleSheet("color: green;")
            
        except ValueError:
            self.status_label.setText("❌ 请输入有效的数字")
            self.status_label.setStyleSheet("color: red;")

grid_gui = GridUI()
```

### 复杂网格布局

```python
from PySide import QtGui
import FreeCAD as App
import Part

class AdvancedGridUI(QtGui.QWidget):
    """复杂网格布局示例"""
    
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        self.setWindowTitle("东台中学-数字车间控制台")
        self.setGeometry(300, 300, 500, 400)
        
        # 主布局
        main_layout = QtGui.QVBoxLayout()
        
        # ===== 尺寸设置组 =====
        size_group = QtGui.QGroupBox("📐 尺寸设置")
        size_layout = QtGui.QGridLayout()
        
        # 半径
        size_layout.addWidget(QtGui.QLabel("半径:"), 0, 0)
        self.radius_input = QtGui.QLineEdit("20")
        size_layout.addWidget(self.radius_input, 0, 1)
        size_layout.addWidget(QtGui.QLabel("mm"), 0, 2)
        
        # 高度
        size_layout.addWidget(QtGui.QLabel("高度:"), 1, 0)
        self.height_input = QtGui.QLineEdit("50")
        size_layout.addWidget(self.height_input, 1, 1)
        size_layout.addWidget(QtGui.QLabel("mm"), 1, 2)
        
        # 壁厚
        size_layout.addWidget(QtGui.QLabel("壁厚:"), 2, 0)
        self.thickness_input = QtGui.QLineEdit("2")
        size_layout.addWidget(self.thickness_input, 2, 1)
        size_layout.addWidget(QtGui.QLabel("mm"), 2, 2)
        
        size_group.setLayout(size_layout)
        main_layout.addWidget(size_group)
        
        # ===== 外观设置组 =====
        appearance_group = QtGui.QGroupBox("🎨 外观设置")
        appearance_layout = QtGui.QGridLayout()
        
        # 颜色
        appearance_layout.addWidget(QtGui.QLabel("颜色:"), 0, 0)
        self.color_combo = QtGui.QComboBox()
        self.color_combo.addItems(["红色", "绿色", "蓝色", "黄色", "紫色"])
        appearance_layout.addWidget(self.color_combo, 0, 1)
        
        # 透明度
        appearance_layout.addWidget(QtGui.QLabel("透明度:"), 1, 0)
        self.transparency_slider = QtGui.QSlider(QtGui.Qt.Horizontal)
        self.transparency_slider.setRange(0, 100)
        self.transparency_slider.setValue(0)
        appearance_layout.addWidget(self.transparency_slider, 1, 1)
        
        appearance_group.setLayout(appearance_layout)
        main_layout.addWidget(appearance_group)
        
        # ===== 操作按钮组 =====
        button_layout = QtGui.QHBoxLayout()
        
        self.generate_btn = QtGui.QPushButton("✨ 生成")
        self.generate_btn.clicked.connect(self.generate)
        self.generate_btn.setStyleSheet("background-color: #4CAF50; color: white; padding: 10px;")
        
        self.preview_btn = QtGui.QPushButton("👁️ 预览")
        self.preview_btn.clicked.connect(self.preview)
        
        self.reset_btn = QtGui.QPushButton("🔄 重置")
        self.reset_btn.clicked.connect(self.reset)
        
        button_layout.addWidget(self.generate_btn)
        button_layout.addWidget(self.preview_btn)
        button_layout.addWidget(self.reset_btn)
        
        main_layout.addLayout(button_layout)
        
        # ===== 状态栏 =====
        self.status_label = QtGui.QLabel("就绪 - 等待操作...")
        self.status_label.setStyleSheet("color: #666; border-top: 1px solid #ccc; padding-top: 10px;")
        main_layout.addWidget(self.status_label)
        
        self.setLayout(main_layout)
        self.show()
    
    def generate(self):
        try:
            r = float(self.radius_input.text())
            h = float(self.height_input.text())
            t = float(self.thickness_input.text())
            
            # 创建带壁厚的圆柱体
            outer = Part.makeCylinder(r, h)
            inner = Part.makeCylinder(r - t, h)
            inner.translate(App.Vector(0, 0, t))
            
            tube = outer.cut(inner)
            
            obj = App.ActiveDocument.addObject("Part::Feature", "Tube")
            obj.Shape = tube
            
            # 设置颜色
            colors = {
                "红色": (1.0, 0.0, 0.0),
                "绿色": (0.0, 1.0, 0.0),
                "蓝色": (0.0, 0.0, 1.0),
                "黄色": (1.0, 1.0, 0.0),
                "紫色": (1.0, 0.0, 1.0),
            }
            obj.ViewObject.ShapeColor = colors[self.color_combo.currentText()]
            
            # 设置透明度
            obj.ViewObject.Transparency = self.transparency_slider.value()
            
            App.ActiveDocument.recompute()
            
            self.status_label.setText(f"✅ 管道生成成功！R={r}mm, H={h}mm, T={t}mm")
            self.status_label.setStyleSheet("color: green; border-top: 1px solid #ccc; padding-top: 10px;")
            
        except ValueError:
            self.status_label.setText("❌ 错误：请输入有效的数字")
            self.status_label.setStyleSheet("color: red; border-top: 1px solid #ccc; padding-top: 10px;")
    
    def preview(self):
        self.status_label.setText("👁️ 预览模式已激活")
    
    def reset(self):
        self.radius_input.setText("20")
        self.height_input.setText("50")
        self.thickness_input.setText("2")
        self.color_combo.setCurrentIndex(0)
        self.transparency_slider.setValue(0)
        self.status_label.setText("已重置为默认值")

grid_gui = AdvancedGridUI()
```

---

## 📋 实验报告

### 观察记录

运行网格布局代码后：
1. ✅ 界面变得非常专业整洁
2. ✅ 控件像电子表格一样对齐
3. ✅ 一个完整的定制级"数字车间控制台"诞生了

### 布局分析

| 组件 | 布局方式 | 作用 |
|:---|:---|:---|
| QLabel + QLineEdit | 网格布局 | 标签和输入框对齐 |
| QGroupBox | 垂直布局 | 功能分组 |
| QPushButton | 水平布局 | 操作按钮排列 |
| 跨列组件 | addWidget(widget, row, col, rowspan, colspan) | 合并单元格 |

### 思考问题

1. 如何让两列的宽度比例不同？
2. 如何在布局中添加间距？
3. 如何实现响应式布局（窗口大小变化时自适应）？

---

## 🔧 制作指南

### 布局嵌套

```python
from PySide import QtGui

# 创建主布局（垂直）
main_layout = QtGui.QVBoxLayout()

# 创建子布局（水平）
top_layout = QtGui.QHBoxLayout()
top_layout.addWidget(QtGui.QPushButton("按钮1"))
top_layout.addWidget(QtGui.QPushButton("按钮2"))

# 创建子布局（网格）
center_layout = QtGui.QGridLayout()
center_layout.addWidget(QtGui.QLabel("标签1"), 0, 0)
center_layout.addWidget(QtGui.QLineEdit(), 0, 1)

# 将子布局添加到主布局
main_layout.addLayout(top_layout)
main_layout.addLayout(center_layout)
```

### 设置间距

```python
# 设置布局边距
layout.setContentsMargins(10, 10, 10, 10)  # 左、上、右、下

# 设置控件间距
layout.setSpacing(10)

# 在特定位置添加间距
layout.addSpacing(20)

# 添加弹性空间
layout.addStretch()
```

### 设置列宽比例

```python
# 设置第1列的拉伸因子为2（第0列默认为1）
layout.setColumnStretch(1, 2)

# 设置行高
layout.setRowStretch(0, 1)
```

---

## 🎯 课后挑战

### 挑战1：创建完整的参数化齿轮生成器

```python
from PySide import QtGui
import FreeCAD as App
import Part
import math

class GearGeneratorUI(QtGui.QWidget):
    """齿轮生成器"""
    
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        self.setWindowTitle("⚙️ 参数化齿轮生成器")
        self.setGeometry(300, 300, 450, 350)
        
        main_layout = QtGui.QVBoxLayout()
        
        # 基本参数组
        basic_group = QtGui.QGroupBox("基本参数")
        basic_layout = QtGui.QGridLayout()
        
        basic_layout.addWidget(QtGui.QLabel("模数:"), 0, 0)
        self.module_input = QtGui.QLineEdit("2")
        basic_layout.addWidget(self.module_input, 0, 1)
        
        basic_layout.addWidget(QtGui.QLabel("齿数:"), 1, 0)
        self.teeth_input = QtGui.QLineEdit("20")
        basic_layout.addWidget(self.teeth_input, 1, 1)
        
        basic_layout.addWidget(QtGui.QLabel("厚度:"), 2, 0)
        self.thickness_input = QtGui.QLineEdit("10")
        basic_layout.addWidget(self.thickness_input, 2, 1)
        
        basic_group.setLayout(basic_layout)
        main_layout.addWidget(basic_group)
        
        # 孔参数组
        hole_group = QtGui.QGroupBox("中心孔")
        hole_layout = QtGui.QGridLayout()
        
        hole_layout.addWidget(QtGui.QLabel("孔径:"), 0, 0)
        self.hole_input = QtGui.QLineEdit("5")
        hole_layout.addWidget(self.hole_input, 0, 1)
        
        self.hole_check = QtGui.QCheckBox("添加中心孔")
        self.hole_check.setChecked(True)
        hole_layout.addWidget(self.hole_check, 1, 0, 1, 2)
        
        hole_group.setLayout(hole_layout)
        main_layout.addWidget(hole_group)
        
        # 按钮
        btn_layout = QtGui.QHBoxLayout()
        self.generate_btn = QtGui.QPushButton("生成齿轮")
        self.generate_btn.clicked.connect(self.generate)
        self.generate_btn.setStyleSheet("background-color: #2196F3; color: white; padding: 10px;")
        
        btn_layout.addStretch()
        btn_layout.addWidget(self.generate_btn)
        btn_layout.addStretch()
        
        main_layout.addLayout(btn_layout)
        
        # 状态
        self.status_label = QtGui.QLabel("就绪")
        self.status_label.setAlignment(QtGui.Qt.AlignCenter)
        main_layout.addWidget(self.status_label)
        
        self.setLayout(main_layout)
        self.show()
    
    def generate(self):
        try:
            module_val = float(self.module_input.text())
            teeth = int(self.teeth_input.text())
            thickness = float(self.thickness_input.text())
            hole_radius = float(self.hole_input.text())
            
            # 计算齿轮半径
            pitch_radius = module_val * teeth / 2
            
            # 创建齿轮主体（简化版：圆柱）
            gear = Part.makeCylinder(pitch_radius, thickness)
            
            # 添加中心孔
            if self.hole_check.isChecked():
                hole = Part.makeCylinder(hole_radius, thickness)
                gear = gear.cut(hole)
            
            obj = App.ActiveDocument.addObject("Part::Feature", "Gear")
            obj.Shape = gear
            obj.ViewObject.ShapeColor = (0.8, 0.8, 0.2)
            
            App.ActiveDocument.recompute()
            
            self.status_label.setText(f"✅ 齿轮生成：模数={module_val}，齿数={teeth}")
            self.status_label.setStyleSheet("color: green;")
            
        except ValueError:
            self.status_label.setText("❌ 请输入有效的数字")
            self.status_label.setStyleSheet("color: red;")

gear_gui = GearGeneratorUI()
```

---

## 📚 知识小结

### 本课重点

1. ✅ 理解了网格布局的概念和用法
2. ✅ 掌握了QGridLayout的基本操作
3. ✅ 学会了创建专业的GUI界面

### 关键API

| 方法 | 说明 |
|:---|:---|
| `QGridLayout()` | 创建网格布局 |
| `addWidget(w, row, col)` | 在指定位置添加控件 |
| `addWidget(w, r, c, rs, cs)` | 添加跨越多行/列的控件 |
| `setColumnStretch(col, factor)` | 设置列的拉伸因子 |
| `QGroupBox(title)` | 创建分组框 |
| `setSpacing(n)` | 设置控件间距 |

### 布局设计原则

1. **对齐**：使用网格布局保持对齐
2. **分组**：使用GroupBox组织相关控件
3. **层次**：重要信息放在显眼位置
4. **反馈**：状态标签显示操作结果

> **`QGridLayout` 是最强大的布局工具，掌握它，你就能设计出市面上 90% 软件的界面。**

---

> **"好的布局是界面设计的灵魂，让专业感扑面而来！"** 🎨

---

<p align="center">
  <a href="#/module5/lesson15">下一课：时间循环（QTimer 与自动动画）→</a>
</p>

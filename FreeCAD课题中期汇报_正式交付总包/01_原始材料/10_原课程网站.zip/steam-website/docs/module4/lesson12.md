# 📍 第 12 课：维度控制器（QSlider 滑动条交互）

> **"将滑动条离散的整型数值通过数学比例运算，映射为3D模型的物理尺寸或旋转弧度。"**

---

## 📐 物理/数理原理

### 线性映射

在机械工程中，连杆和铰链的运动是连续的。为了在计算机中模拟这种连续的物理状态，我们需要建立**UI控件数值与物体物理属性之间的线性映射关系**。

**映射公式**：
$$\text{物理值} = \text{最小值} + \frac{\text{滑动条值} - \text{滑动条最小值}}{\text{滑动条最大值} - \text{滑动条最小值}} \times (\text{物理最大值} - \text{物理最小值})$$

**简化版**：
```
物理值 = 滑动条值 × 比例系数
```

> 💡 **应用场景**：机械臂控制、参数化设计、实时预览等。

---

## 💻 FreeCAD 脚本

### 基础滑动条

```python
from PySide import QtCore, QtGui
import FreeCAD as App
import Part

class SliderUI(QtGui.QWidget):
    """滑动条控制窗口"""
    
    def __init__(self):
        super().__init__()
        self.initUI()
        self.setup_object()
    
    def initUI(self):
        self.setWindowTitle('东台中学-机械臂维度控制器')
        self.setGeometry(300, 300, 400, 200)
        
        layout = QtGui.QVBoxLayout()
        
        # 创建标签
        self.label = QtGui.QLabel('拖动滑动条控制方块大小：10mm')
        layout.addWidget(self.label)
        
        # 创建滑动条
        self.slider = QtGui.QSlider(QtCore.Qt.Horizontal, self)
        self.slider.setRange(10, 100)  # 设置滑动范围 10mm 到 100mm
        self.slider.setValue(10)       # 初始值
        self.slider.setTickPosition(QtGui.QSlider.TicksBelow)
        self.slider.setTickInterval(10)
        
        # 绑定事件
        self.slider.valueChanged.connect(self.update_model)
        
        layout.addWidget(self.slider)
        
        # 添加说明标签
        info = QtGui.QLabel('💡 提示：拖动滑动条实时改变方块尺寸')
        info.setStyleSheet('color: #666; font-size: 12px;')
        layout.addWidget(info)
        
        self.setLayout(layout)
        self.show()
    
    def setup_object(self):
        """初始化3D对象"""
        self.doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()
        self.box_obj = self.doc.addObject("Part::Feature", "DynamicBox")
        self.box_obj.Shape = Part.makeBox(10, 10, 10)
        self.doc.recompute()
    
    def update_model(self, val):
        """滑动条数值改变时调用"""
        # 更新标签
        self.label.setText(f'拖动滑动条控制方块大小：{val}mm')
        
        # 实时修改方块尺寸
        self.box_obj.Shape = Part.makeBox(val, val, val)
        self.doc.recompute()
        
        App.Console.PrintMessage(f"方块尺寸更新为：{val}mm\n")

# 启动控制器
slider_gui = SliderUI()
```

### 多滑动条控制

```python
from PySide import QtCore, QtGui
import FreeCAD as App
import Part

class MultiSliderUI(QtGui.QWidget):
    """多滑动条控制器"""
    
    def __init__(self):
        super().__init__()
        self.initUI()
        self.setup_object()
    
    def initUI(self):
        self.setWindowTitle('多维度控制器')
        self.setGeometry(300, 300, 400, 300)
        
        layout = QtGui.QFormLayout()
        
        # X轴滑动条
        self.slider_x = QtGui.QSlider(QtCore.Qt.Horizontal)
        self.slider_x.setRange(10, 100)
        self.slider_x.setValue(20)
        self.slider_x.valueChanged.connect(self.update_model)
        self.label_x = QtGui.QLabel('20')
        
        # Y轴滑动条
        self.slider_y = QtGui.QSlider(QtCore.Qt.Horizontal)
        self.slider_y.setRange(10, 100)
        self.slider_y.setValue(20)
        self.slider_y.valueChanged.connect(self.update_model)
        self.label_y = QtGui.QLabel('20')
        
        # Z轴滑动条
        self.slider_z = QtGui.QSlider(QtCore.Qt.Horizontal)
        self.slider_z.setRange(10, 100)
        self.slider_z.setValue(20)
        self.slider_z.valueChanged.connect(self.update_model)
        self.label_z = QtGui.QLabel('20')
        
        # 添加到布局
        layout.addRow('长度 (X):', self.label_x)
        layout.addRow(self.slider_x)
        layout.addRow('宽度 (Y):', self.label_y)
        layout.addRow(self.slider_y)
        layout.addRow('高度 (Z):', self.label_z)
        layout.addRow(self.slider_z)
        
        self.setLayout(layout)
        self.show()
    
    def setup_object(self):
        self.doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()
        self.box_obj = self.doc.addObject("Part::Feature", "DynamicBox")
        self.box_obj.Shape = Part.makeBox(20, 20, 20)
        self.doc.recompute()
    
    def update_model(self):
        x = self.slider_x.value()
        y = self.slider_y.value()
        z = self.slider_z.value()
        
        self.label_x.setText(str(x))
        self.label_y.setText(str(y))
        self.label_z.setText(str(z))
        
        self.box_obj.Shape = Part.makeBox(x, y, z)
        self.doc.recompute()

slider_gui = MultiSliderUI()
```

---

## 📋 实验报告

### 观察记录

运行滑动条代码后：
1. ✅ 拖动滑动条，屏幕上的长方体如同拥有生命一般，长度随着鼠标的滑动实时伸缩
2. ✅ 滑动条范围是10-100，对应方块的尺寸
3. ✅ 每次滑动都会触发 `update_model` 函数

### 事件流程分析

```
用户拖动滑动条 → valueChanged信号发射 → update_model(val)被调用 → 更新3D模型
```

### 思考问题

1. 如何让滑动条的步长为5而不是1？
2. 如何用滑动条控制旋转角度？
3. 频繁的 `recompute()` 会导致什么问题？

---

## 🔧 制作指南

### 滑动条常用属性

```python
from PySide import QtCore, QtGui

slider = QtGui.QSlider(QtCore.Qt.Horizontal)

# 设置范围
slider.setMinimum(0)    # 最小值
slider.setMaximum(100)  # 最大值
slider.setRange(0, 100) # 同时设置最小最大值

# 设置当前值
slider.setValue(50)

# 设置步长
slider.setSingleStep(1)   # 单步步长
slider.setPageStep(10)    # 翻页步长

# 显示刻度
slider.setTickPosition(QtGui.QSlider.TicksBelow)
slider.setTickInterval(10)  # 刻度间隔

# 获取当前值
current_value = slider.value()
```

### 旋转控制

```python
from PySide import QtCore, QtGui
import FreeCAD as App
import Part
from FreeCAD import Vector
import math

class RotationSliderUI(QtGui.QWidget):
    """旋转控制器"""
    
    def __init__(self):
        super().__init__()
        self.initUI()
        self.setup_object()
    
    def initUI(self):
        self.setWindowTitle('旋转控制器')
        self.setGeometry(300, 300, 400, 200)
        
        layout = QtGui.QVBoxLayout()
        
        # 旋转角度滑动条
        self.label = QtGui.QLabel('旋转角度：0°')
        layout.addWidget(self.label)
        
        self.slider = QtGui.QSlider(QtCore.Qt.Horizontal)
        self.slider.setRange(0, 360)  # 0到360度
        self.slider.setValue(0)
        self.slider.valueChanged.connect(self.update_rotation)
        
        layout.addWidget(self.slider)
        
        # 重置按钮
        self.reset_btn = QtGui.QPushButton('重置')
        self.reset_btn.clicked.connect(self.reset_rotation)
        layout.addWidget(self.reset_btn)
        
        self.setLayout(layout)
        self.show()
    
    def setup_object(self):
        self.doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()
        self.obj = self.doc.addObject("Part::Feature", "RotatableBox")
        self.obj.Shape = Part.makeBox(30, 10, 10)
        self.obj.Placement.Base = Vector(0, 0, 0)
        self.doc.recompute()
    
    def update_rotation(self, angle):
        self.label.setText(f'旋转角度：{angle}°')
        
        # 将角度转换为弧度
        rad = math.radians(angle)
        
        # 设置旋转（绕Z轴）
        self.obj.Placement.Rotation.Axis = Vector(0, 0, 1)
        self.obj.Placement.Rotation.Angle = rad
        
        self.doc.recompute()
    
    def reset_rotation(self):
        self.slider.setValue(0)

slider_gui = RotationSliderUI()
```

### 性能优化

```python
from PySide import QtCore, QtGui
import FreeCAD as App
import Part

class OptimizedSliderUI(QtGui.QWidget):
    """优化的滑动条控制器"""
    
    def __init__(self):
        super().__init__()
        self.initUI()
        self.setup_object()
        
        # 创建定时器，用于节流
        self.timer = QtCore.QTimer()
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self.do_update)
        self.pending_value = None
    
    def initUI(self):
        self.setWindowTitle('优化版维度控制器')
        self.setGeometry(300, 300, 400, 150)
        
        layout = QtGui.QVBoxLayout()
        
        self.label = QtGui.QLabel('尺寸：10mm')
        layout.addWidget(self.label)
        
        self.slider = QtGui.QSlider(QtCore.Qt.Horizontal)
        self.slider.setRange(10, 100)
        self.slider.setValue(10)
        self.slider.valueChanged.connect(self.on_slider_changed)
        
        layout.addWidget(self.slider)
        
        info = QtGui.QLabel('💡 使用定时器节流，避免卡顿')
        info.setStyleSheet('color: #666; font-size: 12px;')
        layout.addWidget(info)
        
        self.setLayout(layout)
        self.show()
    
    def setup_object(self):
        self.doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()
        self.box_obj = self.doc.addObject("Part::Feature", "DynamicBox")
        self.box_obj.Shape = Part.makeBox(10, 10, 10)
        self.doc.recompute()
    
    def on_slider_changed(self, val):
        self.pending_value = val
        self.label.setText(f'尺寸：{val}mm')
        
        # 重启定时器，延迟100毫秒后更新
        self.timer.stop()
        self.timer.start(100)
    
    def do_update(self):
        if self.pending_value is not None:
            self.box_obj.Shape = Part.makeBox(self.pending_value, self.pending_value, self.pending_value)
            self.doc.recompute()

slider_gui = OptimizedSliderUI()
```

---

## 🎯 课后挑战

### 挑战1：创建颜色控制器

```python
from PySide import QtCore, QtGui
import FreeCAD as App
import Part

class ColorSliderUI(QtGui.QWidget):
    """RGB颜色控制器"""
    
    def __init__(self):
        super().__init__()
        self.initUI()
        self.setup_object()
    
    def initUI(self):
        self.setWindowTitle('RGB颜色控制器')
        self.setGeometry(300, 300, 400, 250)
        
        layout = QtGui.QFormLayout()
        
        # R滑动条
        self.slider_r = QtGui.QSlider(QtCore.Qt.Horizontal)
        self.slider_r.setRange(0, 255)
        self.slider_r.setValue(128)
        self.slider_r.valueChanged.connect(self.update_color)
        
        # G滑动条
        self.slider_g = QtGui.QSlider(QtCore.Qt.Horizontal)
        self.slider_g.setRange(0, 255)
        self.slider_g.setValue(128)
        self.slider_g.valueChanged.connect(self.update_color)
        
        # B滑动条
        self.slider_b = QtGui.QSlider(QtCore.Qt.Horizontal)
        self.slider_b.setRange(0, 255)
        self.slider_b.setValue(128)
        self.slider_b.valueChanged.connect(self.update_color)
        
        # 颜色预览标签
        self.color_preview = QtGui.QLabel('颜色预览')
        self.color_preview.setStyleSheet('background-color: rgb(128, 128, 128); padding: 20px;')
        
        layout.addRow('红色 (R):', self.slider_r)
        layout.addRow('绿色 (G):', self.slider_g)
        layout.addRow('蓝色 (B):', self.slider_b)
        layout.addRow(self.color_preview)
        
        self.setLayout(layout)
        self.show()
    
    def setup_object(self):
        self.doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()
        self.obj = self.doc.addObject("Part::Feature", "ColorfulBox")
        self.obj.Shape = Part.makeBox(30, 30, 30)
        self.doc.recompute()
    
    def update_color(self):
        r = self.slider_r.value()
        g = self.slider_g.value()
        b = self.slider_b.value()
        
        # 更新预览
        self.color_preview.setStyleSheet(f'background-color: rgb({r}, {g}, {b}); padding: 20px;')
        
        # 更新3D模型颜色（FreeCAD使用0-1范围）
        self.obj.ViewObject.ShapeColor = (r/255, g/255, b/255)

slider_gui = ColorSliderUI()
```

---

## 📚 知识小结

### 本课重点

1. ✅ 理解了滑动条与物理属性的映射关系
2. ✅ 掌握了QSlider的基本用法
3. ✅ 学会了实时更新3D模型

### 关键API

| 方法 | 说明 |
|:---|:---|
| `QSlider(Qt.Horizontal)` | 创建水平滑动条 |
| `setRange(min, max)` | 设置范围 |
| `setValue(val)` | 设置当前值 |
| `value()` | 获取当前值 |
| `valueChanged.connect(func)` | 绑定值改变事件 |

### 性能优化技巧

> ⚠️ **频繁的 `recompute()` 可能会导致画面卡顿**，这是因为每次变化都在重新计算 3D 网格。

解决方案：
1. 使用定时器节流（Throttling）
2. 只在滑动结束时更新
3. 降低模型复杂度

---

> **"指尖拨动，世界旋转，这就是交互的魅力！"** 🎚️

---

<p align="center">
  <a href="#/module4/lesson13">下一课：数据录入舱（QLineEdit 文本与数值转换）→</a>
</p>

# 📍 第 11 课：告别黑框（PySide 基础与按钮）

> **"GUI界面处于监听状态，当捕捉到用户的'点击'事件时，触发绑定的回调函数执行。"**

---

## 📐 物理/数理原理

### 事件驱动模型（Event-Driven）

**传统程序**：按顺序执行，从第一行到最后一行
**事件驱动程序**：
- 程序处于"监听"状态，等待用户操作
- 当事件发生时（如点击按钮），触发对应的处理函数
- 处理完成后，继续监听

**事件类型**：
- 鼠标点击（Click）
- 键盘输入（KeyPress）
- 窗口移动（Move）
- 定时器触发（Timeout）

> 💡 **实际应用**：所有图形界面软件（Windows、手机APP、网页）都基于事件驱动模型。

---

## 💻 FreeCAD 脚本

### 基础GUI窗口

```python
from PySide import QtGui
import FreeCAD as App
import Part

class SimpleUI(QtGui.QWidget):
    """简单的GUI窗口类"""
    
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        """初始化用户界面"""
        # 设置窗口标题
        self.setWindowTitle('东台中学-魔法造物台')
        
        # 设置窗口大小和位置
        self.setGeometry(300, 300, 300, 150)
        
        # 创建一个按钮
        self.btn = QtGui.QPushButton('✨ 生成标准齿轮', self)
        self.btn.setGeometry(50, 50, 200, 40)
        
        # 绑定事件：点击按钮时调用 make_gear 函数
        self.btn.clicked.connect(self.make_gear)
        
        # 显示窗口
        self.show()
    
    def make_gear(self):
        """点击按钮后执行的函数"""
        # 用圆柱示意齿轮坯
        gear = Part.makeCylinder(10, 2)
        Part.show(gear)
        App.Console.PrintMessage("✅ 齿轮生成成功！\n")

# 实例化并显示窗口
gui = SimpleUI()
```

### 带多个按钮的窗口

```python
from PySide import QtGui
import FreeCAD as App
import Part

class MultiButtonUI(QtGui.QWidget):
    """多按钮GUI窗口"""
    
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        self.setWindowTitle('东台中学-几何体生成器')
        self.setGeometry(300, 300, 300, 250)
        
        # 创建垂直布局
        layout = QtGui.QVBoxLayout()
        
        # 创建标题标签
        title = QtGui.QLabel('选择要生成的几何体：')
        layout.addWidget(title)
        
        # 创建按钮
        self.btn_sphere = QtGui.QPushButton('🔵 生成球体')
        self.btn_box = QtGui.QPushButton('📦 生成正方体')
        self.btn_cylinder = QtGui.QPushButton('🔧 生成圆柱体')
        self.btn_clear = QtGui.QPushButton('🗑️ 清空场景')
        
        # 绑定事件
        self.btn_sphere.clicked.connect(self.make_sphere)
        self.btn_box.clicked.connect(self.make_box)
        self.btn_cylinder.clicked.connect(self.make_cylinder)
        self.btn_clear.clicked.connect(self.clear_scene)
        
        # 添加按钮到布局
        layout.addWidget(self.btn_sphere)
        layout.addWidget(self.btn_box)
        layout.addWidget(self.btn_cylinder)
        layout.addWidget(self.btn_clear)
        
        # 设置布局
        self.setLayout(layout)
        self.show()
    
    def make_sphere(self):
        sphere = Part.makeSphere(10)
        Part.show(sphere)
        App.Console.PrintMessage("🔵 球体生成成功！\n")
    
    def make_box(self):
        box = Part.makeBox(15, 15, 15)
        Part.show(box)
        App.Console.PrintMessage("📦 正方体生成成功！\n")
    
    def make_cylinder(self):
        cylinder = Part.makeCylinder(8, 20)
        Part.show(cylinder)
        App.Console.PrintMessage("🔧 圆柱体生成成功！\n")
    
    def clear_scene(self):
        doc = App.ActiveDocument
        for obj in list(doc.Objects):
            doc.removeObject(obj.Name)
        doc.recompute()
        App.Console.PrintMessage("🗑️ 场景已清空！\n")

# 启动GUI
gui = MultiButtonUI()
```

---

## 📋 实验报告

### 观察记录

运行基础GUI代码后：
1. ✅ 在 FreeCAD 中弹出了一个我们自己编写的按钮窗口
2. ✅ 点击按钮，场景中自动生成了模型
3. ✅ 控制台输出了成功信息

### 事件流程分析

```
用户点击按钮 → 触发 clicked 事件 → 调用 make_gear() 函数 → 生成3D模型
```

### 思考问题

1. 如何修改按钮的文字和颜色？
2. 如何在点击按钮时传递参数？
3. 如何关闭窗口？

---

## 🔧 制作指南

### 常用控件

```python
from PySide import QtGui

# 标签（Label）
label = QtGui.QLabel('这是标签文字')

# 按钮（PushButton）
button = QtGui.QPushButton('点击我')

# 单行文本输入（LineEdit）
line_edit = QtGui.QLineEdit()
line_edit.setPlaceholderText('请输入内容')

# 多行文本（TextEdit）
text_edit = QtGui.QTextEdit()

# 复选框（CheckBox）
checkbox = QtGui.QCheckBox('选项')

# 单选按钮（RadioButton）
radio = QtGui.QRadioButton('选择')

# 下拉框（ComboBox）
combo = QtGui.QComboBox()
combo.addItem('选项1')
combo.addItem('选项2')
```

### 布局管理

```python
from PySide import QtGui

# 垂直布局（从上到下）
vbox = QtGui.QVBoxLayout()
vbox.addWidget(widget1)
vbox.addWidget(widget2)
vbox.addWidget(widget3)

# 水平布局（从左到右）
hbox = QtGui.QHBoxLayout()
hbox.addWidget(widget1)
hbox.addWidget(widget2)

# 嵌套布局
main_layout = QtGui.QVBoxLayout()
main_layout.addLayout(hbox)
main_layout.addWidget(widget3)
```

### 窗口样式美化

```python
from PySide import QtGui

class StyledUI(QtGui.QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        self.setWindowTitle('样式美化示例')
        self.setGeometry(300, 300, 300, 200)
        
        # 设置窗口背景色
        self.setStyleSheet("""
            QWidget {
                background-color: #f0f0f0;
            }
            QPushButton {
                background-color: #3F51B5;
                color: white;
                border: none;
                padding: 10px;
                border-radius: 5px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #5C6BC0;
            }
            QLabel {
                color: #333;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        
        layout = QtGui.QVBoxLayout()
        
        label = QtGui.QLabel('✨ 欢迎使用代码造物')
        layout.addWidget(label)
        
        btn = QtGui.QPushButton('开始创造')
        layout.addWidget(btn)
        
        self.setLayout(layout)
        self.show()

gui = StyledUI()
```

---

## 🎯 课后挑战

### 挑战1：创建参数输入窗口

```python
from PySide import QtGui
import FreeCAD as App
import Part

class ParametricUI(QtGui.QWidget):
    """参数化输入窗口"""
    
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        self.setWindowTitle('参数化几何体生成器')
        self.setGeometry(300, 300, 350, 200)
        
        layout = QtGui.QFormLayout()
        
        # 创建输入框
        self.radius_input = QtGui.QLineEdit('10')
        self.height_input = QtGui.QLineEdit('20')
        
        # 创建生成按钮
        self.generate_btn = QtGui.QPushButton('生成圆柱体')
        self.generate_btn.clicked.connect(self.generate)
        
        # 添加到表单布局
        layout.addRow('半径:', self.radius_input)
        layout.addRow('高度:', self.height_input)
        layout.addRow(self.generate_btn)
        
        self.setLayout(layout)
        self.show()
    
    def generate(self):
        try:
            radius = float(self.radius_input.text())
            height = float(self.height_input.text())
            
            cylinder = Part.makeCylinder(radius, height)
            Part.show(cylinder)
            
            App.Console.PrintMessage(f"✅ 圆柱体生成：半径={radius}, 高度={height}\n")
        except ValueError:
            QtGui.QMessageBox.warning(self, '输入错误', '请输入有效的数字！')

gui = ParametricUI()
```

### 挑战2：创建带状态显示的窗口

```python
from PySide import QtGui
import FreeCAD as App
import Part

class StatusUI(QtGui.QWidget):
    """带状态显示的窗口"""
    
    def __init__(self):
        super().__init__()
        self.object_count = 0
        self.initUI()
    
    def initUI(self):
        self.setWindowTitle('状态监控面板')
        self.setGeometry(300, 300, 300, 200)
        
        layout = QtGui.QVBoxLayout()
        
        # 状态标签
        self.status_label = QtGui.QLabel('当前对象数量：0')
        self.status_label.setStyleSheet('font-size: 16px; color: #3F51B5;')
        layout.addWidget(self.status_label)
        
        # 按钮
        self.add_btn = QtGui.QPushButton('➕ 添加球体')
        self.add_btn.clicked.connect(self.add_sphere)
        
        self.clear_btn = QtGui.QPushButton('🗑️ 清空所有')
        self.clear_btn.clicked.connect(self.clear_all)
        
        layout.addWidget(self.add_btn)
        layout.addWidget(self.clear_btn)
        
        self.setLayout(layout)
        self.show()
    
    def add_sphere(self):
        sphere = Part.makeSphere(10)
        Part.show(sphere)
        self.object_count += 1
        self.update_status()
    
    def clear_all(self):
        doc = App.ActiveDocument
        for obj in list(doc.Objects):
            doc.removeObject(obj.Name)
        doc.recompute()
        self.object_count = 0
        self.update_status()
    
    def update_status(self):
        self.status_label.setText(f'当前对象数量：{self.object_count}')

gui = StatusUI()
```

---

## 📚 知识小结

### 本课重点

1. ✅ 理解了事件驱动编程模型
2. ✅ 掌握了创建GUI窗口的基本方法
3. ✅ 学会了按钮事件绑定

### 关键概念

| 概念 | 说明 |
|:---|:---|
| 事件驱动 | 程序响应用户操作的模式 |
| 信号（Signal） | 控件发出的通知（如clicked） |
| 槽（Slot） | 响应信号的函数 |
| 布局（Layout） | 管理控件排列的方式 |

### GUI开发流程

```python
1. 创建窗口类，继承自 QWidget
2. 在 __init__ 中调用 initUI()
3. 在 initUI() 中：
   - 设置窗口属性（标题、大小）
   - 创建控件（按钮、标签等）
   - 绑定事件
   - 设置布局
   - 显示窗口
4. 定义事件处理函数
5. 实例化窗口类
```

> **`gui = SimpleUI()` 这一步必须实例化并保存在全局变量中，否则窗口会一闪而退被内存回收。**

---

> **"告别黑框，拥抱图形界面，让你的程序更专业！"** 🎨

---

<p align="center">
  <a href="#/module4/lesson12">下一课：维度控制器（QSlider 滑动条交互）→</a>
</p>

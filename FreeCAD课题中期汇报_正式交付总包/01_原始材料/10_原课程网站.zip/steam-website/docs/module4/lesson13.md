# 📍 第 13 课：数据录入舱（QLineEdit 文本与数值转换）

> **"用户在界面输入的本质上是字符串，需要转换为浮点数才能参与几何尺寸计算。"**

---

## 📐 物理/数理原理

### 数据类型转换（Type Casting）

在计算机中，不同类型的数据有不同的表示方式：
- **字符串（String）**：文本，如 `"10.5"`、`"Hello"`
- **整数（Integer）**：如 `10`、`-5`
- **浮点数（Float）**：如 `10.5`、`-3.14`

**为什么需要转换？**
- GUI输入框接收的是字符串
- 数学运算需要数值类型
- 3D建模API需要浮点数参数

**转换过程**：
```
用户输入 "15.5" → 字符串
          ↓
    float("15.5") → 浮点数 15.5
          ↓
    Part.makeSphere(15.5) → 3D模型
```

> 💡 **实际应用**：所有需要精确输入参数的工业软件（CAD、财务系统等）都需要这种转换。

---

## 💻 FreeCAD 脚本

### 基础文本输入

```python
from PySide import QtGui
import FreeCAD as App
import Part

class InputUI(QtGui.QWidget):
    """文本输入窗口"""
    
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        self.setWindowTitle('东台中学-数据录入舱')
        self.setGeometry(300, 300, 350, 200)
        
        layout = QtGui.QFormLayout()
        
        # 创建输入框
        self.radius_input = QtGui.QLineEdit("15.5")  # 默认值
        self.radius_input.setPlaceholderText("请输入半径")
        
        # 创建生成按钮
        self.generate_btn = QtGui.QPushButton('生成定制圆球')
        self.generate_btn.clicked.connect(self.generate)
        
        # 添加到布局
        layout.addRow('半径 (mm):', self.radius_input)
        layout.addRow(self.generate_btn)
        
        # 添加说明
        info = QtGui.QLabel('💡 支持小数输入，如：10.5')
        info.setStyleSheet('color: #666; font-size: 12px;')
        layout.addRow(info)
        
        self.setLayout(layout)
        self.show()
    
    def generate(self):
        try:
            # 将字符串转换为浮点数
            radius = float(self.radius_input.text())
            
            # 验证输入
            if radius <= 0:
                QtGui.QMessageBox.warning(self, '输入错误', '半径必须大于0！')
                return
            
            # 生成球体
            sphere = Part.makeSphere(radius)
            Part.show(sphere)
            
            App.Console.PrintMessage(f"✅ 球体生成成功！半径：{radius}mm\n")
            
        except ValueError:
            QtGui.QMessageBox.critical(self, '转换错误', '请输入有效的数字！\n例如：10 或 15.5')

# 启动输入舱
input_gui = InputUI()
```

### 多参数输入

```python
from PySide import QtGui
import FreeCAD as App
import Part

class MultiInputUI(QtGui.QWidget):
    """多参数输入窗口"""
    
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        self.setWindowTitle('参数化圆柱体生成器')
        self.setGeometry(300, 300, 350, 250)
        
        layout = QtGui.QFormLayout()
        
        # 半径输入
        self.radius_input = QtGui.QLineEdit("10")
        self.radius_input.setValidator(QtGui.QDoubleValidator(0.1, 1000, 2))
        
        # 高度输入
        self.height_input = QtGui.QLineEdit("20")
        self.height_input.setValidator(QtGui.QDoubleValidator(0.1, 1000, 2))
        
        # 生成按钮
        self.generate_btn = QtGui.QPushButton('生成圆柱体')
        self.generate_btn.clicked.connect(self.generate)
        
        # 重置按钮
        self.reset_btn = QtGui.QPushButton('重置默认值')
        self.reset_btn.clicked.connect(self.reset)
        
        # 按钮布局
        btn_layout = QtGui.QHBoxLayout()
        btn_layout.addWidget(self.generate_btn)
        btn_layout.addWidget(self.reset_btn)
        
        layout.addRow('半径 (mm):', self.radius_input)
        layout.addRow('高度 (mm):', self.height_input)
        layout.addRow(btn_layout)
        
        self.setLayout(layout)
        self.show()
    
    def generate(self):
        try:
            radius = float(self.radius_input.text())
            height = float(self.height_input.text())
            
            cylinder = Part.makeCylinder(radius, height)
            Part.show(cylinder)
            
            App.Console.PrintMessage(f"✅ 圆柱体生成：半径={radius}mm，高度={height}mm\n")
            
        except ValueError:
            QtGui.QMessageBox.critical(self, '错误', '请输入有效的数字！')
    
    def reset(self):
        self.radius_input.setText("10")
        self.height_input.setText("20")

input_gui = MultiInputUI()
```

---

## 📋 实验报告

### 观察记录

运行文本输入代码后：
1. ✅ 我们成功实现了一个带有输入框的微型工业软件
2. ✅ 输入精确的小数，就能生成对应尺寸的球体
3. ✅ 输入无效时会弹出错误提示

### 数据转换流程

| 步骤 | 数据 | 类型 |
|:---:|:---|:---|
| 1 | 用户在输入框输入 "15.5" | 字符串 |
| 2 | `float("15.5")` | 转换 |
| 3 | 得到 15.5 | 浮点数 |
| 4 | `Part.makeSphere(15.5)` | 生成模型 |

### 思考问题

1. 如果输入 `"abc"` 会发生什么？
2. 如何限制输入只能是正数？
3. 如何验证输入的范围（如10-100之间）？

---

## 🔧 制作指南

### 输入验证

```python
from PySide import QtGui

# 创建输入框
line_edit = QtGui.QLineEdit()

# 设置验证器（只能输入数字）
# 整数验证器
int_validator = QtGui.QIntValidator(1, 1000)
line_edit.setValidator(int_validator)

# 浮点数验证器
float_validator = QtGui.QDoubleValidator(0.1, 1000.0, 2)
line_edit.setValidator(float_validator)
```

### 错误处理

```python
from PySide import QtGui

def safe_convert(input_text):
    """
    安全地将字符串转换为浮点数
    
    返回:
        (success, value_or_error_message)
    """
    try:
        # 尝试转换
        value = float(input_text)
        
        # 验证范围
        if value < 0:
            return False, "数值不能为负数"
        
        if value > 1000:
            return False, "数值不能超过1000"
        
        return True, value
        
    except ValueError:
        return False, "请输入有效的数字"

# 使用示例
success, result = safe_convert("15.5")
if success:
    print(f"转换成功：{result}")
else:
    print(f"错误：{result}")
```

### 完整验证示例

```python
from PySide import QtGui
import FreeCAD as App
import Part

class ValidatedInputUI(QtGui.QWidget):
    """带完整验证的输入窗口"""
    
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        self.setWindowTitle('验证输入示例')
        self.setGeometry(300, 300, 350, 200)
        
        layout = QtGui.QFormLayout()
        
        # 半径输入（带验证器）
        self.radius_input = QtGui.QLineEdit("10")
        validator = QtGui.QDoubleValidator(0.1, 500, 2, self)
        validator.setNotation(QtGui.QDoubleValidator.StandardNotation)
        self.radius_input.setValidator(validator)
        
        # 生成按钮
        self.generate_btn = QtGui.QPushButton('生成')
        self.generate_btn.clicked.connect(self.generate)
        
        layout.addRow('半径 (0.1-500mm):', self.radius_input)
        layout.addRow(self.generate_btn)
        
        self.setLayout(layout)
        self.show()
    
    def generate(self):
        text = self.radius_input.text()
        
        # 检查是否为空
        if not text:
            QtGui.QMessageBox.warning(self, '错误', '请输入数值！')
            return
        
        try:
            radius = float(text)
            
            # 额外验证
            if radius < 0.1:
                QtGui.QMessageBox.warning(self, '错误', '半径不能小于0.1mm！')
                return
            
            if radius > 500:
                QtGui.QMessageBox.warning(self, '错误', '半径不能超过500mm！')
                return
            
            # 生成模型
            sphere = Part.makeSphere(radius)
            Part.show(sphere)
            
            QtGui.QMessageBox.information(self, '成功', f'球体生成成功！\n半径：{radius}mm')
            
        except ValueError:
            QtGui.QMessageBox.critical(self, '错误', '输入格式不正确！')

input_gui = ValidatedInputUI()
```

---

## 🎯 课后挑战

### 挑战1：创建完整参数化盒子生成器

```python
from PySide import QtGui
import FreeCAD as App
import Part

class BoxGeneratorUI(QtGui.QWidget):
    """完整参数化盒子生成器"""
    
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        self.setWindowTitle('参数化盒子生成器')
        self.setGeometry(300, 300, 400, 300)
        
        layout = QtGui.QFormLayout()
        
        # 三个维度的输入
        self.length_input = QtGui.QLineEdit("50")
        self.width_input = QtGui.QLineEdit("30")
        self.height_input = QtGui.QLineEdit("20")
        
        # 设置验证器
        for input_field in [self.length_input, self.width_input, self.height_input]:
            input_field.setValidator(QtGui.QDoubleValidator(0.1, 1000, 2))
        
        # 生成按钮
        self.generate_btn = QtGui.QPushButton('生成盒子')
        self.generate_btn.clicked.connect(self.generate)
        
        # 预览信息
        self.preview_label = QtGui.QLabel('体积：--- mm³')
        self.preview_label.setStyleSheet('color: #3F51B5; font-weight: bold;')
        
        # 连接预览更新
        for input_field in [self.length_input, self.width_input, self.height_input]:
            input_field.textChanged.connect(self.update_preview)
        
        layout.addRow('长度 (mm):', self.length_input)
        layout.addRow('宽度 (mm):', self.width_input)
        layout.addRow('高度 (mm):', self.height_input)
        layout.addRow(self.preview_label)
        layout.addRow(self.generate_btn)
        
        self.setLayout(layout)
        self.show()
    
    def update_preview(self):
        try:
            l = float(self.length_input.text() or 0)
            w = float(self.width_input.text() or 0)
            h = float(self.height_input.text() or 0)
            volume = l * w * h
            self.preview_label.setText(f'体积：{volume:.2f} mm³')
        except:
            self.preview_label.setText('体积：--- mm³')
    
    def generate(self):
        try:
            l = float(self.length_input.text())
            w = float(self.width_input.text())
            h = float(self.height_input.text())
            
            box = Part.makeBox(l, w, h)
            Part.show(box)
            
            App.Console.PrintMessage(f"✅ 盒子生成：{l} x {w} x {h} mm\n")
            
        except ValueError:
            QtGui.QMessageBox.critical(self, '错误', '请输入有效的数字！')

input_gui = BoxGeneratorUI()
```

---

## 📚 知识小结

### 本课重点

1. ✅ 理解了字符串与数值类型的区别
2. ✅ 掌握了数据类型转换的方法
3. ✅ 学会了输入验证和错误处理

### 关键API

| 方法 | 说明 |
|:---|:---|
| `QLineEdit()` | 创建文本输入框 |
| `text()` | 获取输入的文本 |
| `setText(str)` | 设置文本 |
| `float(str)` | 字符串转浮点数 |
| `int(str)` | 字符串转整数 |
| `setValidator()` | 设置输入验证器 |

### 错误处理模板

```python
try:
    value = float(input_text)
    # 使用value
except ValueError:
    # 处理错误
    print("请输入有效的数字")
```

> **如果在输入框里输入了字母，点击生成时 Python 会报错 `ValueError`。在真实的软件开发中，这里需要加 `try-except` 错误处理。**

---

> **"数据是代码的血液，准确的输入是精确输出的保证！"** 💉

---

<p align="center">
  <a href="#/module4/lesson14">下一课：我的定制工坊（GUI网格布局设计）→</a>
</p>

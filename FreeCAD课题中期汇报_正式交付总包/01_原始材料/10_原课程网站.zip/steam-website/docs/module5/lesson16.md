# 📍 第 16 课：空间碰撞（AABB 边界框干涉检测）

> **"两个刚体不能占据同一个物理空间，使用轴对齐边界框来极速判断物体是否发生碰撞。"**

---

## 📐 物理/数理原理

### 空间干涉与AABB算法

**空间干涉（Collision）**：两个或多个物体占据同一物理空间的现象。

**AABB算法**（Axis-Aligned Bounding Box，轴对齐边界框）：
- 为每个复杂几何体计算一个包含它的最小立方体盒子
- 盒子与坐标轴对齐（不旋转）
- 通过判断两个盒子在X、Y、Z三个轴上的投影是否重叠，快速判断是否碰撞

**AABB的优点**：
- 计算速度快（只需比较坐标）
- 实现简单
- 适合粗略检测

**AABB的局限**：
- 不够精确（盒子可能比实际物体大）
- 对旋转物体效果不佳

> 💡 **实际应用**：3D游戏开发、机器人运动规划、物理引擎等。

---

## 💻 FreeCAD 脚本

### 基础碰撞检测

```python
import FreeCAD as App
import Part
from FreeCAD import Vector

# 确保有活动文档
doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()

# 创建两个测试物体
# 物体1：移动的方块
box = Part.makeBox(20, 20, 20)
actor = doc.addObject("Part::Feature", "MovingBox")
actor.Shape = box
actor.Placement.Base = Vector(0, 0, 0)
actor.ViewObject.ShapeColor = (0.2, 0.6, 1.0)

# 物体2：墙壁
cylinder = Part.makeCylinder(15, 30)
obstacle = doc.addObject("Part::Feature", "Wall")
obstacle.Shape = cylinder
obstacle.Placement.Base = Vector(50, 0, 0)
obstacle.ViewObject.ShapeColor = (0.0, 1.0, 0.0)  # 初始绿色

doc.recompute()

# 碰撞检测函数
def check_collision():
    """检测两个物体是否发生碰撞"""
    # 获取两个物体的包围盒
    actor_bbox = actor.Shape.BoundBox
    obstacle_bbox = obstacle.Shape.BoundBox
    
    # 判断是否相交
    if actor_bbox.intersect(obstacle_bbox):
        App.Console.PrintMessage("【警告】发生空间碰撞！\n")
        obstacle.ViewObject.ShapeColor = (1.0, 0.0, 0.0)  # 变红
        return True
    else:
        App.Console.PrintMessage("安全距离。\n")
        obstacle.ViewObject.ShapeColor = (0.0, 1.0, 0.0)  # 绿色安全
        return False

# 测试碰撞检测
App.Console.PrintMessage("=== 碰撞检测测试 ===\n")
check_collision()

# 移动方块靠近墙壁
actor.Placement.Base = Vector(35, 0, 0)
doc.recompute()

App.Console.PrintMessage("\n移动后再次检测...\n")
check_collision()
```

### 带GUI的碰撞检测系统

```python
from PySide import QtCore, QtGui
import FreeCAD as App
import Part
from FreeCAD import Vector

class CollisionDetectionUI(QtGui.QWidget):
    """碰撞检测系统"""
    
    def __init__(self):
        super().__init__()
        self.initUI()
        self.setup_objects()
    
    def initUI(self):
        self.setWindowTitle("🚨 空间碰撞检测系统")
        self.setGeometry(300, 300, 400, 250)
        
        layout = QtGui.QVBoxLayout()
        
        # 标题
        title = QtGui.QLabel("AABB 碰撞检测演示")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: #3F51B5;")
        title.setAlignment(QtGui.Qt.AlignCenter)
        layout.addWidget(title)
        
        # 位置控制
        pos_layout = QtGui.QHBoxLayout()
        pos_layout.addWidget(QtGui.QLabel("方块X位置:"))
        self.pos_slider = QtGui.QSlider(QtCore.Qt.Horizontal)
        self.pos_slider.setRange(0, 80)
        self.pos_slider.setValue(0)
        self.pos_slider.valueChanged.connect(self.update_position)
        pos_layout.addWidget(self.pos_slider)
        layout.addLayout(pos_layout)
        
        # 位置显示
        self.pos_label = QtGui.QLabel("当前位置：X = 0 mm")
        self.pos_label.setAlignment(QtGui.Qt.AlignCenter)
        layout.addWidget(self.pos_label)
        
        # 检测按钮
        self.check_btn = QtGui.QPushButton("🔍 执行碰撞检测")
        self.check_btn.clicked.connect(self.check_collision)
        self.check_btn.setStyleSheet("background-color: #2196F3; color: white; padding: 10px;")
        layout.addWidget(self.check_btn)
        
        # 状态显示
        self.status_label = QtGui.QLabel("状态：等待检测...")
        self.status_label.setAlignment(QtGui.Qt.AlignCenter)
        self.status_label.setStyleSheet("font-size: 14px; padding: 10px; border: 2px solid #ccc;")
        layout.addWidget(self.status_label)
        
        self.setLayout(layout)
        self.show()
    
    def setup_objects(self):
        """创建测试物体"""
        self.doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()
        
        # 移动的方块
        box = Part.makeBox(20, 20, 20)
        self.actor = self.doc.addObject("Part::Feature", "MovingBox")
        self.actor.Shape = box
        self.actor.Placement.Base = Vector(0, 0, 0)
        self.actor.ViewObject.ShapeColor = (0.2, 0.6, 1.0)
        
        # 障碍物（墙壁）
        wall = Part.makeBox(20, 40, 30)
        self.obstacle = self.doc.addObject("Part::Feature", "Wall")
        self.obstacle.Shape = wall
        self.obstacle.Placement.Base = Vector(60, -10, -5)
        self.obstacle.ViewObject.ShapeColor = (0.0, 1.0, 0.0)
        
        self.doc.recompute()
    
    def update_position(self, value):
        """更新方块位置"""
        self.actor.Placement.Base = Vector(value, 0, 0)
        self.doc.recompute()
        self.pos_label.setText(f"当前位置：X = {value} mm")
        
        # 自动检测
        self.check_collision()
    
    def check_collision(self):
        """执行碰撞检测"""
        # 获取包围盒
        actor_bbox = self.actor.Shape.BoundBox
        obstacle_bbox = self.obstacle.Shape.BoundBox
        
        # 检测碰撞
        if actor_bbox.intersect(obstacle_bbox):
            self.status_label.setText("🚨 警告：发生碰撞！")
            self.status_label.setStyleSheet("font-size: 14px; padding: 10px; border: 2px solid red; background-color: #ffebee;")
            self.obstacle.ViewObject.ShapeColor = (1.0, 0.0, 0.0)
        else:
            # 计算距离
            distance = self.calculate_distance(actor_bbox, obstacle_bbox)
            self.status_label.setText(f"✅ 安全距离：{distance:.1f} mm")
            self.status_label.setStyleSheet("font-size: 14px; padding: 10px; border: 2px solid green; background-color: #e8f5e9;")
            self.obstacle.ViewObject.ShapeColor = (0.0, 1.0, 0.0)
    
    def calculate_distance(self, bbox1, bbox2):
        """计算两个包围盒之间的距离"""
        # 计算X轴距离
        if bbox1.XMax < bbox2.XMin:
            dx = bbox2.XMin - bbox1.XMax
        elif bbox2.XMax < bbox1.XMin:
            dx = bbox1.XMin - bbox2.XMax
        else:
            dx = 0
        
        # 简化：只计算X轴距离
        return dx

# 启动系统
collision_ui = CollisionDetectionUI()
```

---

## 📋 实验报告

### 观察记录

运行碰撞检测代码后：
1. ✅ 当移动的方块触碰到墙壁模型时，墙壁瞬间变成了红色
2. ✅ 我们为虚拟世界加入了物理法则
3. ✅ AABB检测快速准确地识别了碰撞

### 包围盒属性

| 属性 | 说明 |
|:---|:---|
| `XMin`, `XMax` | X轴最小/最大值 |
| `YMin`, `YMax` | Y轴最小/最大值 |
| `ZMin`, `ZMax` | Z轴最小/最大值 |
| `Center` | 中心点 |
| `DiagonalLength` | 对角线长度 |

### 思考问题

1. 如何检测多个物体之间的碰撞？
2. 如何实现更精确的碰撞检测（非AABB）？
3. 碰撞检测在游戏开发中有什么应用？

---

## 🔧 制作指南

### 包围盒可视化

```python
import FreeCAD as App
import Part
from FreeCAD import Vector

def show_bounding_box(obj, doc):
    """显示物体的包围盒"""
    bbox = obj.Shape.BoundBox
    
    # 创建包围盒的线框
    # 底面四个点
    p1 = Vector(bbox.XMin, bbox.YMin, bbox.ZMin)
    p2 = Vector(bbox.XMax, bbox.YMin, bbox.ZMin)
    p3 = Vector(bbox.XMax, bbox.YMax, bbox.ZMin)
    p4 = Vector(bbox.XMin, bbox.YMax, bbox.ZMin)
    
    # 顶面四个点
    p5 = Vector(bbox.XMin, bbox.YMin, bbox.ZMax)
    p6 = Vector(bbox.XMax, bbox.YMin, bbox.ZMax)
    p7 = Vector(bbox.XMax, bbox.YMax, bbox.ZMax)
    p8 = Vector(bbox.XMin, bbox.YMax, bbox.ZMax)
    
    # 创建边
    edges = [
        Part.makeLine(p1, p2), Part.makeLine(p2, p3),
        Part.makeLine(p3, p4), Part.makeLine(p4, p1),
        Part.makeLine(p5, p6), Part.makeLine(p6, p7),
        Part.makeLine(p7, p8), Part.makeLine(p8, p5),
        Part.makeLine(p1, p5), Part.makeLine(p2, p6),
        Part.makeLine(p3, p7), Part.makeLine(p4, p8),
    ]
    
    # 创建复合形状
    bbox_shape = Part.Compound(edges)
    bbox_obj = doc.addObject("Part::Feature", f"{obj.Name}_BBox")
    bbox_obj.Shape = bbox_shape
    bbox_obj.ViewObject.LineColor = (1.0, 0.5, 0.0)
    bbox_obj.ViewObject.LineWidth = 2.0
    
    return bbox_obj

# 使用示例
doc = App.ActiveDocument
box = Part.makeBox(20, 30, 40)
obj = doc.addObject("Part::Feature", "TestBox")
obj.Shape = box

# 显示包围盒
show_bounding_box(obj, doc)
doc.recompute()
```

### 多物体碰撞检测

```python
import FreeCAD as App

def check_all_collisions(objects):
    """
    检测列表中所有物体之间的碰撞
    
    返回:
        碰撞对列表 [(obj1, obj2), ...]
    """
    collisions = []
    
    for i in range(len(objects)):
        for j in range(i + 1, len(objects)):
            obj1 = objects[i]
            obj2 = objects[j]
            
            if obj1.Shape.BoundBox.intersect(obj2.Shape.BoundBox):
                collisions.append((obj1, obj2))
                App.Console.PrintMessage(f"碰撞：{obj1.Name} 与 {obj2.Name}\n")
    
    return collisions

# 使用示例
doc = App.ActiveDocument
all_objects = [obj for obj in doc.Objects if obj.isDerivedFrom("Part::Feature")]
collisions = check_all_collisions(all_objects)
App.Console.PrintMessage(f"发现 {len(collisions)} 处碰撞\n")
```

---

## 🎯 课后挑战

### 挑战1：创建简单的物理模拟

```python
from PySide import QtCore, QtGui
import FreeCAD as App
import Part
from FreeCAD import Vector

class SimplePhysicsUI(QtGui.QWidget):
    """简单物理模拟"""
    
    def __init__(self):
        super().__init__()
        self.velocity = Vector(2, 0, 0)  # 初始速度
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.update)
        self.initUI()
        self.setup_objects()
    
    def initUI(self):
        self.setWindowTitle("⚙️ 简单物理模拟")
        self.setGeometry(300, 300, 300, 150)
        
        layout = QtGui.QVBoxLayout()
        
        btn_layout = QtGui.QHBoxLayout()
        
        self.start_btn = QtGui.QPushButton("▶️ 开始")
        self.start_btn.clicked.connect(self.start)
        
        self.stop_btn = QtGui.QPushButton("⏸️ 停止")
        self.stop_btn.clicked.connect(self.stop)
        
        self.reset_btn = QtGui.QPushButton("🔄 重置")
        self.reset_btn.clicked.connect(self.reset)
        
        btn_layout.addWidget(self.start_btn)
        btn_layout.addWidget(self.stop_btn)
        btn_layout.addWidget(self.reset_btn)
        
        layout.addLayout(btn_layout)
        
        self.status_label = QtGui.QLabel("就绪")
        self.status_label.setAlignment(QtGui.Qt.AlignCenter)
        layout.addWidget(self.status_label)
        
        self.setLayout(layout)
        self.show()
    
    def setup_objects(self):
        self.doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()
        
        # 移动物体
        box = Part.makeBox(15, 15, 15)
        self.ball = self.doc.addObject("Part::Feature", "Ball")
        self.ball.Shape = box
        self.ball.Placement.Base = Vector(0, 0, 0)
        self.ball.ViewObject.ShapeColor = (0.2, 0.6, 1.0)
        
        # 边界
        wall = Part.makeBox(5, 50, 30)
        self.wall = self.doc.addObject("Part::Feature", "Boundary")
        self.wall.Shape = wall
        self.wall.Placement.Base = Vector(80, -10, -5)
        self.wall.ViewObject.ShapeColor = (0.5, 0.5, 0.5)
        
        self.doc.recompute()
        self.initial_pos = Vector(0, 0, 0)
    
    def update(self):
        # 获取当前位置
        current_pos = self.ball.Placement.Base
        
        # 检测碰撞
        if self.ball.Shape.BoundBox.intersect(self.wall.Shape.BoundBox):
            # 反弹
            self.velocity = Vector(-self.velocity.x, 0, 0)
            self.status_label.setText("碰撞！反弹")
            self.status_label.setStyleSheet("color: red;")
        else:
            self.status_label.setText("运动中...")
            self.status_label.setStyleSheet("color: green;")
        
        # 更新位置
        new_pos = current_pos + self.velocity
        self.ball.Placement.Base = new_pos
        self.doc.recompute()
    
    def start(self):
        self.timer.start(50)
    
    def stop(self):
        self.timer.stop()
    
    def reset(self):
        self.stop()
        self.ball.Placement.Base = self.initial_pos
        self.velocity = Vector(2, 0, 0)
        self.doc.recompute()
        self.status_label.setText("已重置")

ui = SimplePhysicsUI()
```

---

## 📚 知识小结

### 本课重点

1. ✅ 理解了碰撞检测的基本原理
2. ✅ 掌握了AABB包围盒的使用
3. ✅ 学会了创建简单的碰撞检测系统

### 关键API

| 属性/方法 | 说明 |
|:---|:---|
| `Shape.BoundBox` | 获取包围盒 |
| `BoundBox.intersect(other)` | 检测是否相交 |
| `XMin`, `XMax`, `YMin`, `YMax`, `ZMin`, `ZMax` | 包围盒边界 |

### 碰撞检测流程

```python
1. 获取物体A的包围盒 bbox_a
2. 获取物体B的包围盒 bbox_b
3. 调用 bbox_a.intersect(bbox_b)
4. 返回True表示碰撞，False表示安全
```

> **BoundBox（包围盒）是一个包裹物体的隐形立方体，它是 3D 游戏开发中做碰撞检测的基础。**

---

> **"碰撞检测是虚拟世界的物理法则，让数字世界更加真实！"** 🚨

---

<p align="center">
  <a href="#/module5/lesson17">下一课：轨迹追踪（B-Spline 与路径运动）→</a>
</p>

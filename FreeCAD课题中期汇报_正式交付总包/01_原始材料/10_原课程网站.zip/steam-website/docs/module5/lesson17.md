# 📍 第 17 课：轨迹追踪（B-Spline 与路径运动）

> **"利用参数 t (0 到 1)，获取曲线上特定比例处的精确三维坐标，实现平滑移动。"**

---

## 📐 物理/数理原理

### 质点沿曲线的运动

在物理学中，**质点沿曲线运动**需要知道：
1. 曲线的数学方程
2. 质点在曲线上的位置（参数 $t$）

**参数化曲线**：
$$P(t) = (x(t), y(t), z(t)), \quad t \in [0, 1]$$

其中：
- $t = 0$：曲线的起点
- $t = 1$：曲线的终点
- $t = 0.5$：曲线的中点

**B样条曲线（B-Spline）**：
- 通过控制点定义的平滑曲线
- 具有良好的局部控制性
- 广泛应用于CAD/CAM系统

> 💡 **应用场景**：无人机航线、机械臂轨迹、过山车轨道、动画路径等。

---

## 💻 FreeCAD 脚本

### 基础路径运动

```python
import FreeCAD as App
import Part
from FreeCAD import Vector

doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()

# 创建一条曲线路径
path_points = [
    Vector(0, 0, 0),
    Vector(30, 50, 20),
    Vector(60, 0, 40),
    Vector(90, 50, 20),
    Vector(120, 0, 0)
]

# 创建B样条曲线
path_curve = Part.BSplineCurve()
path_curve.buildFromPoles(path_points)
path_edge = Part.Edge(path_curve)

# 显示路径
path_obj = doc.addObject("Part::Feature", "Path")
path_obj.Shape = path_edge
path_obj.ViewObject.LineColor = (0.0, 0.5, 1.0)
path_obj.ViewObject.LineWidth = 3.0

# 创建运动物体（小球）
ball = Part.makeSphere(5)
ball_obj = doc.addObject("Part::Feature", "Ball")
ball_obj.Shape = ball
ball_obj.ViewObject.ShapeColor = (1.0, 0.2, 0.2)

# 获取曲线上 50% 处的精确三维坐标
target_vector = path_obj.Shape.Edge1.valueAt(0.5)

# 将小球移动到该坐标点
ball_obj.Placement.Base = target_vector

doc.recompute()

App.Console.PrintMessage(f"小球已移动到曲线中点：{target_vector}\n")
```

### 沿路径移动的动画

```python
from PySide import QtCore, QtGui
import FreeCAD as App
import Part
from FreeCAD import Vector

class PathAnimationUI(QtGui.QWidget):
    """路径动画控制器"""
    
    def __init__(self):
        super().__init__()
        self.t = 0.0  # 当前参数位置
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.update_position)
        self.initUI()
        self.setup_objects()
    
    def initUI(self):
        self.setWindowTitle("🎢 路径运动控制")
        self.setGeometry(300, 300, 400, 200)
        
        layout = QtGui.QVBoxLayout()
        
        # 标题
        title = QtGui.QLabel("B-Spline 轨迹追踪")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: #3F51B5;")
        title.setAlignment(QtGui.Qt.AlignCenter)
        layout.addWidget(title)
        
        # 进度控制
        self.progress_label = QtGui.QLabel("进度：0%")
        self.progress_label.setAlignment(QtGui.Qt.AlignCenter)
        layout.addWidget(self.progress_label)
        
        self.progress_slider = QtGui.QSlider(QtCore.Qt.Horizontal)
        self.progress_slider.setRange(0, 100)
        self.progress_slider.setValue(0)
        self.progress_slider.valueChanged.connect(self.on_slider_changed)
        layout.addWidget(self.progress_slider)
        
        # 按钮
        btn_layout = QtGui.QHBoxLayout()
        
        self.start_btn = QtGui.QPushButton("▶️ 播放")
        self.start_btn.clicked.connect(self.start)
        
        self.stop_btn = QtGui.QPushButton("⏸️ 暂停")
        self.stop_btn.clicked.connect(self.stop)
        
        self.reset_btn = QtGui.QPushButton("🔄 重置")
        self.reset_btn.clicked.connect(self.reset)
        
        btn_layout.addWidget(self.start_btn)
        btn_layout.addWidget(self.stop_btn)
        btn_layout.addWidget(self.reset_btn)
        
        layout.addLayout(btn_layout)
        self.setLayout(layout)
        self.show()
    
    def setup_objects(self):
        self.doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()
        
        # 创建曲线路径
        path_points = [
            Vector(0, 0, 0),
            Vector(25, 40, 30),
            Vector(50, 0, 60),
            Vector(75, 40, 30),
            Vector(100, 0, 0)
        ]
        
        path_curve = Part.BSplineCurve()
        path_curve.buildFromPoles(path_points)
        path_edge = Part.Edge(path_curve)
        
        self.path_obj = self.doc.addObject("Part::Feature", "Path")
        self.path_obj.Shape = path_edge
        self.path_obj.ViewObject.LineColor = (0.0, 0.5, 1.0)
        self.path_obj.ViewObject.LineWidth = 3.0
        
        # 创建运动小球
        ball = Part.makeSphere(4)
        self.ball_obj = self.doc.addObject("Part::Feature", "Ball")
        self.ball_obj.Shape = ball
        self.ball_obj.ViewObject.ShapeColor = (1.0, 0.2, 0.2)
        
        # 放置到起点
        start_pos = self.path_obj.Shape.Edge1.valueAt(0.0)
        self.ball_obj.Placement.Base = start_pos
        
        self.doc.recompute()
    
    def update_position(self):
        """更新小球位置"""
        # 增加进度
        self.t += 0.01
        
        if self.t >= 1.0:
            self.t = 1.0
            self.timer.stop()
        
        # 更新滑块
        self.progress_slider.setValue(int(self.t * 100))
        
        # 获取曲线上的点
        point = self.path_obj.Shape.Edge1.valueAt(self.t)
        
        # 移动小球
        self.ball_obj.Placement.Base = point
        self.doc.recompute()
        
        # 更新标签
        self.progress_label.setText(f"进度：{int(self.t * 100)}%")
    
    def on_slider_changed(self, value):
        """滑块改变时"""
        self.t = value / 100.0
        self.progress_label.setText(f"进度：{value}%")
        
        # 获取曲线上的点
        point = self.path_obj.Shape.Edge1.valueAt(self.t)
        
        # 移动小球
        self.ball_obj.Placement.Base = point
        self.doc.recompute()
    
    def start(self):
        if self.t >= 1.0:
            self.t = 0.0
        self.timer.start(50)
    
    def stop(self):
        self.timer.stop()
    
    def reset(self):
        self.stop()
        self.t = 0.0
        self.progress_slider.setValue(0)
        self.progress_label.setText("进度：0%")
        start_pos = self.path_obj.Shape.Edge1.valueAt(0.0)
        self.ball_obj.Placement.Base = start_pos
        self.doc.recompute()

ui = PathAnimationUI()
```

---

## 📋 实验报告

### 观察记录

运行路径运动代码后：
1. ✅ 小球瞬间吸附并移动到了曲线路径的正中央
2. ✅ 配合 QTimer，小球可以沿着过山车轨道滑动
3. ✅ `valueAt(t)` 建立了数学参数与真实三维空间坐标之间的桥梁

### 参数t的含义

| t值 | 位置 | 说明 |
|:---:|:---|:---|
| 0.0 | 曲线起点 | 开始位置 |
| 0.25 | 25%处 | 四分之一位置 |
| 0.5 | 曲线中点 | 中间位置 |
| 0.75 | 75%处 | 四分之三位置 |
| 1.0 | 曲线终点 | 结束位置 |

### 思考问题

1. 如何让物体始终朝向运动方向？
2. 如何实现变速运动（加速/减速）？
3. 如何让多个物体沿同一路径运动但有时间差？

---

## 🔧 制作指南

### 获取曲线切线方向

```python
import Part
from FreeCAD import Vector

# 获取曲线在某点的切线方向
def get_tangent_at(curve_edge, t):
    """
    获取曲线在参数t处的切线方向
    
    参数:
        curve_edge: 曲线边
        t: 参数（0-1）
    
    返回:
        切线向量
    """
    # 获取当前点
    p1 = curve_edge.valueAt(t)
    
    # 获取稍后的点
    p2 = curve_edge.valueAt(min(t + 0.01, 1.0))
    
    # 计算方向向量
    tangent = p2 - p1
    tangent.normalize()
    
    return tangent

# 使用示例
doc = App.ActiveDocument
path = doc.getObject("Path")
t = 0.5
tangent = get_tangent_at(path.Shape.Edge1, t)
App.Console.PrintMessage(f"切线方向：{tangent}\n")
```

### 创建环形路径

```python
import Part
from FreeCAD import Vector
import math

doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()

# 创建圆形路径
radius = 40
points = []
num_points = 20

for i in range(num_points):
    angle = 2 * math.pi * i / num_points
    x = radius * math.cos(angle)
    y = radius * math.sin(angle)
    z = 5 * math.sin(3 * angle)  # 添加波浪
    points.append(Vector(x, y, z))

# 闭合路径
points.append(points[0])

# 创建B样条曲线
path_curve = Part.BSplineCurve()
path_curve.buildFromPoles(points)
path_edge = Part.Edge(path_curve)

path_obj = doc.addObject("Part::Feature", "CircularPath")
path_obj.Shape = path_edge
path_obj.ViewObject.LineColor = (0.0, 0.8, 0.4)
path_obj.ViewObject.LineWidth = 3.0

doc.recompute()
```

---

## 🎯 课后挑战

### 挑战1：创建过山车模拟

```python
from PySide import QtCore, QtGui
import FreeCAD as App
import Part
from FreeCAD import Vector
import math

class RollerCoasterUI(QtGui.QWidget):
    """过山车模拟器"""
    
    def __init__(self):
        super().__init__()
        self.t = 0.0
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.update)
        self.initUI()
        self.setup_track()
    
    def initUI(self):
        self.setWindowTitle("🎢 过山车模拟器")
        self.setGeometry(300, 300, 350, 180)
        
        layout = QtGui.QVBoxLayout()
        
        btn_layout = QtGui.QHBoxLayout()
        
        self.start_btn = QtGui.QPushButton("▶️ 启动")
        self.start_btn.clicked.connect(self.start)
        
        self.stop_btn = QtGui.QPushButton("⏸️ 停止")
        self.stop_btn.clicked.connect(self.stop)
        
        btn_layout.addWidget(self.start_btn)
        btn_layout.addWidget(self.stop_btn)
        
        layout.addLayout(btn_layout)
        
        self.status_label = QtGui.QLabel("等待启动...")
        self.status_label.setAlignment(QtGui.Qt.AlignCenter)
        layout.addWidget(self.status_label)
        
        self.setLayout(layout)
        self.show()
    
    def setup_track(self):
        self.doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()
        
        # 创建过山车轨道（更复杂的路径）
        track_points = []
        for i in range(50):
            t = i / 49.0
            angle = 4 * math.pi * t
            
            x = 60 * t
            y = 30 * math.sin(angle)
            z = 20 * math.sin(2 * angle) + 10 * t
            
            track_points.append(Vector(x, y, z))
        
        track_curve = Part.BSplineCurve()
        track_curve.buildFromPoles(track_points)
        track_edge = Part.Edge(track_curve)
        
        self.track_obj = self.doc.addObject("Part::Feature", "Track")
        self.track_obj.Shape = track_edge
        self.track_obj.ViewObject.LineColor = (0.5, 0.5, 0.5)
        self.track_obj.ViewObject.LineWidth = 4.0
        
        # 创建车厢
        cart = Part.makeBox(8, 4, 4)
        self.cart_obj = self.doc.addObject("Part::Feature", "Cart")
        self.cart_obj.Shape = cart
        self.cart_obj.ViewObject.ShapeColor = (1.0, 0.0, 0.0)
        
        start_pos = self.track_obj.Shape.Edge1.valueAt(0.0)
        self.cart_obj.Placement.Base = start_pos
        
        self.doc.recompute()
    
    def update(self):
        # 变速运动（模拟重力加速）
        speed = 0.005 + 0.01 * math.sin(self.t * math.pi)
        self.t += speed
        
        if self.t >= 1.0:
            self.t = 1.0
            self.timer.stop()
            self.status_label.setText("到达终点！")
            return
        
        # 获取位置
        pos = self.track_obj.Shape.Edge1.valueAt(self.t)
        self.cart_obj.Placement.Base = pos
        
        # 计算进度
        progress = int(self.t * 100)
        self.status_label.setText(f"运行中... {progress}%")
        
        self.doc.recompute()
    
    def start(self):
        if self.t >= 1.0:
            self.t = 0.0
        self.timer.start(30)
    
    def stop(self):
        self.timer.stop()

ui = RollerCoasterUI()
```

---

## 📚 知识小结

### 本课重点

1. ✅ 理解了参数化曲线的概念
2. ✅ 掌握了B样条曲线的创建和使用
3. ✅ 学会了沿路径运动的实现方法

### 关键API

| 方法 | 说明 |
|:---|:---|
| `BSplineCurve()` | 创建B样条曲线 |
| `buildFromPoles(points)` | 从控制点构建曲线 |
| `Edge(curve)` | 从曲线创建边 |
| `valueAt(t)` | 获取参数t处的坐标 |

### 路径运动流程

```python
1. 创建B样条曲线路径
2. 创建运动物体
3. 使用 valueAt(t) 获取路径上的点
4. 将物体移动到该点
5. 改变t值，重复步骤3-4
```

> **`valueAt(t)` 是曲面建模中极其重要的 API，它建立了数学参数 t 与真实三维空间坐标之间的桥梁。**

---

> **"路径是轨迹的诗，参数是运动的节拍！"** 🎢

---

<p align="center">
  <a href="#/module6/lesson18">下一课：项目蓝图（需求分析与程序架构）→</a>
</p>

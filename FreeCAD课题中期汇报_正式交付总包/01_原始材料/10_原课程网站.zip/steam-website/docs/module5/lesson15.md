# 📍 第 15 课：时间循环（QTimer 与自动动画）

> **"利用定时器剥离主线程，模拟时间的流逝，让几何体动起来。"**

---

## 📐 物理/数理原理

### 角速度

**角速度**（Angular Velocity）描述物体旋转的快慢：
$$\omega = \frac{\Delta \theta}{\Delta t}$$

其中：
- $\omega$：角速度（弧度/秒）
- $\Delta \theta$：角度变化量
- $\Delta t$：时间变化量

**定时器原理**：
- 每隔固定时间间隔（如50毫秒）触发一次
- 每次触发时更新物体的状态（位置、角度等）
- 连续触发形成动画效果

> 💡 **实际应用**：齿轮传动、机械臂运动、风车旋转等。

---

## 💻 FreeCAD 脚本

### 基础定时器动画

```python
from PySide import QtCore
import FreeCAD as App
import Part
from FreeCAD import Vector
import math

# 确保有活动文档
doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()

# 创建一个齿轮（用圆柱代替）
gear = Part.makeCylinder(20, 5)
gear_obj = doc.addObject("Part::Feature", "Gear")
gear_obj.Shape = gear
doc.recompute()

# 动画参数
angle = 0  # 当前角度

def rotate_gear():
    """旋转齿轮的函数"""
    global angle
    
    # 每次增加5度
    angle += 5
    
    # 设置旋转（绕Z轴）
    gear_obj.Placement.Rotation.Axis = Vector(0, 0, 1)
    gear_obj.Placement.Rotation.Angle = math.radians(angle)
    
    # 刷新视图
    doc.recompute()
    
    # 输出当前角度
    App.Console.PrintMessage(f"旋转角度：{angle}°\r")

# 创建定时器
timer = QtCore.QTimer()

# 绑定超时事件
timer.timeout.connect(rotate_gear)

# 启动定时器，每 50 毫秒执行一次
timer.start(50)

App.Console.PrintMessage("动画已启动！输入 timer.stop() 停止\n")
```

### 控制动画的完整GUI

```python
from PySide import QtCore, QtGui
import FreeCAD as App
import Part
from FreeCAD import Vector
import math

class AnimationController(QtGui.QWidget):
    """动画控制器"""
    
    def __init__(self):
        super().__init__()
        self.angle = 0
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.update_animation)
        self.initUI()
        self.setup_object()
    
    def initUI(self):
        self.setWindowTitle("⏱️ 动画控制器")
        self.setGeometry(300, 300, 350, 200)
        
        layout = QtGui.QVBoxLayout()
        
        # 标题
        title = QtGui.QLabel("齿轮旋转控制")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: #3F51B5;")
        title.setAlignment(QtGui.Qt.AlignCenter)
        layout.addWidget(title)
        
        # 速度控制
        speed_layout = QtGui.QHBoxLayout()
        speed_layout.addWidget(QtGui.QLabel("旋转速度:"))
        self.speed_slider = QtGui.QSlider(QtCore.Qt.Horizontal)
        self.speed_slider.setRange(1, 20)
        self.speed_slider.setValue(5)
        speed_layout.addWidget(self.speed_slider)
        layout.addLayout(speed_layout)
        
        # 角度显示
        self.angle_label = QtGui.QLabel("当前角度：0°")
        self.angle_label.setAlignment(QtGui.Qt.AlignCenter)
        layout.addWidget(self.angle_label)
        
        # 按钮
        btn_layout = QtGui.QHBoxLayout()
        
        self.start_btn = QtGui.QPushButton("▶️ 开始")
        self.start_btn.clicked.connect(self.start_animation)
        self.start_btn.setStyleSheet("background-color: #4CAF50; color: white;")
        
        self.stop_btn = QtGui.QPushButton("⏸️ 停止")
        self.stop_btn.clicked.connect(self.stop_animation)
        self.stop_btn.setStyleSheet("background-color: #f44336; color: white;")
        
        self.reset_btn = QtGui.QPushButton("🔄 重置")
        self.reset_btn.clicked.connect(self.reset_animation)
        
        btn_layout.addWidget(self.start_btn)
        btn_layout.addWidget(self.stop_btn)
        btn_layout.addWidget(self.reset_btn)
        
        layout.addLayout(btn_layout)
        
        # 状态
        self.status_label = QtGui.QLabel("就绪")
        self.status_label.setAlignment(QtGui.Qt.AlignCenter)
        layout.addWidget(self.status_label)
        
        self.setLayout(layout)
        self.show()
    
    def setup_object(self):
        """创建3D对象"""
        self.doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()
        
        # 创建齿轮（圆柱）
        gear = Part.makeCylinder(25, 5)
        self.gear_obj = self.doc.addObject("Part::Feature", "AnimatedGear")
        self.gear_obj.Shape = gear
        self.gear_obj.ViewObject.ShapeColor = (0.8, 0.7, 0.2)
        
        # 创建中心轴
        shaft = Part.makeCylinder(5, 8)
        self.shaft_obj = self.doc.addObject("Part::Feature", "Shaft")
        self.shaft_obj.Shape = shaft
        self.shaft_obj.ViewObject.ShapeColor = (0.5, 0.5, 0.5)
        
        self.doc.recompute()
    
    def update_animation(self):
        """更新动画"""
        speed = self.speed_slider.value()
        self.angle += speed
        
        # 限制角度在0-360之间
        if self.angle >= 360:
            self.angle -= 360
        
        # 应用旋转
        self.gear_obj.Placement.Rotation.Axis = Vector(0, 0, 1)
        self.gear_obj.Placement.Rotation.Angle = math.radians(self.angle)
        
        self.doc.recompute()
        
        # 更新显示
        self.angle_label.setText(f"当前角度：{self.angle}°")
    
    def start_animation(self):
        """开始动画"""
        if not self.timer.isActive():
            self.timer.start(50)  # 每50毫秒更新一次
            self.status_label.setText("动画运行中...")
            self.status_label.setStyleSheet("color: green;")
    
    def stop_animation(self):
        """停止动画"""
        if self.timer.isActive():
            self.timer.stop()
            self.status_label.setText("动画已暂停")
            self.status_label.setStyleSheet("color: orange;")
    
    def reset_animation(self):
        """重置动画"""
        self.stop_animation()
        self.angle = 0
        self.gear_obj.Placement.Rotation.Angle = 0
        self.doc.recompute()
        self.angle_label.setText("当前角度：0°")
        self.status_label.setText("已重置")
        self.status_label.setStyleSheet("color: black;")

# 启动控制器
anim_gui = AnimationController()
```

---

## 📋 实验报告

### 观察记录

运行动画代码后：
1. ✅ 无需手动操作，场景中的齿轮开始匀速自转
2. ✅ 我们成功实现了动力学动画
3. ✅ 可以通过GUI控制动画的启动、停止和速度

### 动画参数分析

| 参数 | 值 | 效果 |
|:---|:---:|:---|
| 定时器间隔 | 50ms | 每秒更新20次 |
| 每次旋转角度 | 5° | 平滑的旋转 |
| 旋转轴 | Z轴 | 水平面内旋转 |

### 思考问题

1. 如何让齿轮反向旋转？
2. 如何实现往复摆动而不是单向旋转？
3. 如何让两个齿轮啮合转动？

---

## 🔧 制作指南

### 摆动动画

```python
from PySide import QtCore
import FreeCAD as App
import Part
from FreeCAD import Vector
import math

doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()

# 创建摆锤
pendulum = Part.makeBox(5, 5, 50)
obj = doc.addObject("Part::Feature", "Pendulum")
obj.Shape = pendulum
obj.Placement.Base = Vector(0, -2.5, -50)  # 调整中心点
doc.recompute()

# 摆动参数
time = 0
amplitude = 30  # 摆动幅度（度）
frequency = 0.1  # 频率

def swing():
    global time
    time += 1
    
    # 正弦摆动
    angle = amplitude * math.sin(frequency * time)
    
    # 应用旋转（绕X轴）
    obj.Placement.Rotation.Axis = Vector(1, 0, 0)
    obj.Placement.Rotation.Angle = math.radians(angle)
    
    doc.recompute()

# 创建定时器
timer = QtCore.QTimer()
timer.timeout.connect(swing)
timer.start(50)
```

### 沿路径移动

```python
from PySide import QtCore
import FreeCAD as App
import Part
from FreeCAD import Vector
import math

doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()

# 创建移动物体
ball = Part.makeSphere(5)
obj = doc.addObject("Part::Feature", "MovingBall")
obj.Shape = ball
obj.ViewObject.ShapeColor = (1.0, 0.2, 0.2)
doc.recompute()

# 移动参数
t = 0
radius = 30

def move_in_circle():
    global t
    t += 0.1
    
    # 圆周运动
    x = radius * math.cos(t)
    y = radius * math.sin(t)
    z = 0
    
    obj.Placement.Base = Vector(x, y, z)
    doc.recompute()

# 创建定时器
timer = QtCore.QTimer()
timer.timeout.connect(move_in_circle)
timer.start(50)
```

---

## 🎯 课后挑战

### 挑战1：创建双齿轮啮合动画

```python
from PySide import QtCore, QtGui
import FreeCAD as App
import Part
from FreeCAD import Vector
import math

class GearSystemUI(QtGui.QWidget):
    """双齿轮系统"""
    
    def __init__(self):
        super().__init__()
        self.angle1 = 0
        self.angle2 = 0
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.update_animation)
        self.initUI()
        self.setup_objects()
    
    def initUI(self):
        self.setWindowTitle("⚙️ 双齿轮啮合系统")
        self.setGeometry(300, 300, 350, 180)
        
        layout = QtGui.QVBoxLayout()
        
        # 控制按钮
        btn_layout = QtGui.QHBoxLayout()
        
        self.start_btn = QtGui.QPushButton("▶️ 开始")
        self.start_btn.clicked.connect(self.start)
        
        self.stop_btn = QtGui.QPushButton("⏸️ 停止")
        self.stop_btn.clicked.connect(self.stop)
        
        btn_layout.addWidget(self.start_btn)
        btn_layout.addWidget(self.stop_btn)
        
        layout.addLayout(btn_layout)
        
        # 信息显示
        self.info_label = QtGui.QLabel("齿轮1：0° | 齿轮2：0°")
        self.info_label.setAlignment(QtGui.Qt.AlignCenter)
        layout.addWidget(self.info_label)
        
        self.setLayout(layout)
        self.show()
    
    def setup_objects(self):
        self.doc = App.ActiveDocument if App.ActiveDocument else App.newDocument()
        
        # 齿轮1（大齿轮）
        gear1 = Part.makeCylinder(30, 5)
        self.gear1_obj = self.doc.addObject("Part::Feature", "Gear1")
        self.gear1_obj.Shape = gear1
        self.gear1_obj.Placement.Base = Vector(-35, 0, 0)
        self.gear1_obj.ViewObject.ShapeColor = (0.8, 0.7, 0.2)
        
        # 齿轮2（小齿轮）
        gear2 = Part.makeCylinder(15, 5)
        self.gear2_obj = self.doc.addObject("Part::Feature", "Gear2")
        self.gear2_obj.Shape = gear2
        self.gear2_obj.Placement.Base = Vector(20, 0, 0)
        self.gear2_obj.ViewObject.ShapeColor = (0.2, 0.7, 0.8)
        
        self.doc.recompute()
    
    def update_animation(self):
        # 齿轮1旋转
        self.angle1 += 2
        if self.angle1 >= 360:
            self.angle1 -= 360
        
        # 齿轮2反向旋转（速度是齿轮1的2倍，因为半径是1/2）
        self.angle2 -= 4
        if self.angle2 <= -360:
            self.angle2 += 360
        
        # 应用旋转
        self.gear1_obj.Placement.Rotation.Axis = Vector(0, 0, 1)
        self.gear1_obj.Placement.Rotation.Angle = math.radians(self.angle1)
        
        self.gear2_obj.Placement.Rotation.Axis = Vector(0, 0, 1)
        self.gear2_obj.Placement.Rotation.Angle = math.radians(self.angle2)
        
        self.doc.recompute()
        
        self.info_label.setText(f"齿轮1：{self.angle1}° | 齿轮2：{abs(self.angle2)}°")
    
    def start(self):
        self.timer.start(50)
    
    def stop(self):
        self.timer.stop()

ui = GearSystemUI()
```

---

## 📚 知识小结

### 本课重点

1. ✅ 理解了定时器的工作原理
2. ✅ 掌握了QTimer的基本用法
3. ✅ 学会了创建简单的动画效果

### 关键API

| 方法 | 说明 |
|:---|:---|
| `QTimer()` | 创建定时器 |
| `timeout.connect(func)` | 绑定超时事件 |
| `start(interval)` | 启动定时器（毫秒） |
| `stop()` | 停止定时器 |
| `isActive()` | 检查是否运行中 |

### 动画设计要点

1. **时间间隔**：通常30-50ms，约20-30fps
2. **增量控制**：每次更新的变化量要小，保证平滑
3. **角度转换**：使用 `math.radians()` 将角度转为弧度
4. **性能优化**：复杂模型可能需要降低更新频率

> **注意角度必须通过 `math.radians()` 转换为弧度制才能被物理引擎识别。**

---

> **"时间是动画的灵魂，定时器是时间的节拍器！"** ⏱️

---

<p align="center">
  <a href="#/module5/lesson16">下一课：空间碰撞（AABB 边界框干涉检测）→</a>
</p>
